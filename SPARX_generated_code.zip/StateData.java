public class StateData
{
	public StateData(StateMachineImpl p, StateInitialData pInitialData)
	{
		m_pParent = p;
		state_enum = pInitialData.state_enum;
		region_count = pInitialData.region_count;
		isSubmachineState = pInitialData.isSubmachineState;
		active_count = 0;	
		parent_state = null;
		submachine_state = null;
		
		state_name = pInitialData.state_name;
        state_guid = pInitialData.state_guid;
		
		//For TimingLog
		instanceName = pInitialData.instanceName;
		
		for (int i = 0; i < 1024; i++)
			historyArray[i] = 0;
	}
	
	public void IncrementActiveCount()
	{
		active_count++;
		NotifyStateChange();
		if(active_count == 1)
		{
			m_pParent.GetManager().TimingLog(instanceName, state_guid, "Activate");
		}
	}
	
	public void DecrementActiveCount()
	{
		active_count--;
		NotifyStateChange();
		
		if(active_count == 0)
		{
			m_pParent.GetManager().TimingLog(instanceName, state_guid, "DeActivate");
		}
	}
	
	public boolean IsActiveState()
	{
		if (active_count == 1)
			return true;
		else
			return false;	
	}
	
	public void NotifyStateChange()
	{
		m_pParent.GetManager().OnStateChange(this);	
	}
	
	public StateMachineImpl m_pParent;
	public int active_count;			//when entry, ++; when exit --;	besides, for orthogonal state: when region get activated, ++; when region deActivated, --
	public int region_count;			//submachineState's region count == submachine's region count
	public boolean isSubmachineState;
	public String state_name;
	public String state_guid;
	
	public int state_enum;
	public StateData parent_state = null;
	public StateData submachine_state = null;
	public int[] historyArray = new int[1024];	//array entry represent for each region, the value is the Last Active State's Enum; in order to support history mechanism on submachine state, can not use StateData* as type
	
	//For Timing Logging
	public String instanceName;
};