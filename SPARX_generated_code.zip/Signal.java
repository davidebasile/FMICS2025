import java.util.*;
public class Signal 
{
	public Signal()
	{
		signalEnum = EventProxy.SignalEnum.EMPTY;
	}
	
	public EventProxy.SignalEnum signalEnum;
	public List<String> parameters = new ArrayList<String>();
	public Map<String, String> parameterValues = new Hashtable<String, String>();
};