import java.util.*;
public class GlobalFuncs
{
	public static final int SHARED_MEMORY_STRING_LENGTH = 1024;
	public static final int MAX_STATES = 1024;
	
	public static void ParseEventString(String input, EventData eventData)
	{
		if (input.isEmpty() || eventData == null)
			return;
	
		int pos = input.indexOf(".");
		if (pos != -1)
		{
			eventData.evtStr = input.substring(0, pos);
			String signalWithArguments = input.substring(pos + 1);
			//format: Signal(argument1,argument2,argument3)
			int pos2 = signalWithArguments.indexOf("(");
			int pos3 = signalWithArguments.indexOf(")");
			if (pos2 != -1 && pos3 != -1 && pos3 > pos2)
			{
				eventData.signalStr = signalWithArguments.substring(0, pos2);
				String strArguments = signalWithArguments.substring(pos2 + 1,  pos3);
				String[] argumentArray = strArguments.split(",", -1);
				eventData.arguments = Arrays.asList(argumentArray);
			}
		}
		else
		{
			eventData.evtStr = input;
		}
	}

	public static void trace(String str)
	{
		System.out.print(str);
	}
	
};