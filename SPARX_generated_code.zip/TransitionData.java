public class TransitionData
{
	public TransitionData()
	{
		active = false;
		submachine_state = null;	
	}
	
	public void SetTransition(int transitionEnum_, StateData submachineState_, String name, String guid, String instanceName_)
	{
		transition_enum = transitionEnum_;
		submachine_state = submachineState_;
		active = false;
		if (transition_enum == 0)
		{
			transition_name = "";
			transition_guid = "";
		}
		else
		{
			transition_name = name;
			transition_guid = guid;
		}
		
		instanceName = instanceName_;
	}
	
	public void SetActive(StateMachineImpl p)
	{
		active = true;
		p.GetManager().TimingLog(instanceName, transition_guid, "Transition");
		p.GetManager().OnTransition(this);
	}
	
	public int transition_enum;
	public StateData submachine_state;
	public boolean active;
	public String transition_name;
	public String transition_guid;
	
	//For Timing Logging
	public String instanceName;
};