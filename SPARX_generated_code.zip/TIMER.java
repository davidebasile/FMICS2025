import java.util.*;


/**
 * @author davidebasile
 * @version 1.0
 * @created 17-May-2023 6:32:44 PM
 */
public class TIMER implements StateMachineContext {

	/* Begin - EA generated code for StateMachine */


	enum StateMachineEnum 
	{
		NOSTATEMACHINE,
		TIMER_ENUM_TIMER
	};

	enum StateEnum 
	{
		NOSTATE,
		TIMER_VIRTUAL_SUBMACHINESTATE,
		TIMER_ENUM_TIMER_STATE1
	};

	enum TransitionEnum 
	{
		NOTRANSITION,
		TIMER_ENUM_STATE1__TO__STATE1_3030,
		TIMER_ENUM_INITIAL_829__TO__STATE1_3028
	};

	enum EntryEnum
	{
		NOENTRY,
		TIMER_ENUM_TIMER_INITIAL_829
	};

	public StateMachineImpl m_StateMachineImpl;	
	
	public TIMER()
	{
		m_StateMachineImpl = null;
	}
	
	protected void finalize( ) throws Throwable
	{
	}
	
	public TIMER(ContextManager pManager, String sInstanceName)
	{
		//Initialize Region Variables
		m_timer = StateEnum.NOSTATE;	
		m_sInstanceName = sInstanceName;
		m_sType = "TIMER";
		m_StateMachineImpl = new StateMachineImpl(this, pManager);
	}
	
    public String m_sInstanceName;
    public String m_sType;
	
	public String GetInstanceName()
	{
		return m_sInstanceName;
	}
	
	public String GetTypeName()
	{
		return m_sType;
	}
	
	public boolean defer(Event event, StateData toState)
	{
		if (m_StateMachineImpl == null)
			return false;
		
		boolean bDefer = false;
    
		
		if(!bDefer)
		{
			if(toState.parent_state != null)
			{
				bDefer = defer(event, toState.parent_state);
			}
		}
		return bDefer;
	}

	public void TransitionProc(TransitionEnum transition, Signal signal, StateData submachineState)
	{
		if (m_StateMachineImpl == null)
			return;
		
	
		switch (transition) 
		{
			case TIMER_ENUM_STATE1__TO__STATE1_3030:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "TIMER_State1__TO__State1_3030", "{4726DD75-0710-44eb-B78F-875FB17CCCA1}",m_sInstanceName);
				State1__TO__State1_3030(signal, submachineState); 
				break;
			case TIMER_ENUM_INITIAL_829__TO__STATE1_3028:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "TIMER_Initial_829__TO__State1_3028", "{94E16EC1-C89B-4ac0-8832-6FE4D3645DD3}",m_sInstanceName);
				Initial_829__TO__State1_3028(signal, submachineState); 
				break;
		}
	
		m_StateMachineImpl.currentTransition.SetTransition(TransitionEnum.NOTRANSITION.ordinal(), null, "", "","");	
	}
	
	private void State1__TO__State1_3030_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: State1__TO__State1_3030");
	
	}

	private void State1__TO__State1_3030(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		State1__TO__State1_3030_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
	}
	private void Initial_829__TO__State1_3028_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: Initial_829__TO__State1_3028");
	
	}

	private void Initial_829__TO__State1_3028(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(submachineState != null)
			submachineState.IncrementActiveCount();
		Initial_829__TO__State1_3028_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.TIMER_ENUM_TIMER_STATE1, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal)
	{
		return StateProc(state, submachineState, behavior, signal, EntryTypeEnum.DefaultEntry, null, 0);
	}
	
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType)
	{
		return StateProc(state, submachineState, behavior, signal, enumEntryType, null, 0);
	}
	
	public boolean StateProc(int state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, int[] entryArray, int nArrayCount)
    {
		ArrayList<EntryEnum> entryEnumList = new ArrayList<>();
		if (entryArray != null)
		{
			for(int nEntryIndex : entryArray)
			{
				entryEnumList.add(EntryEnum.values()[nEntryIndex]);
			}
		}
        return StateProc(StateEnum.values()[state], submachineState, behavior, signal, enumEntryType, entryEnumList.toArray(new EntryEnum[entryEnumList.size()]), nArrayCount);
    }
	
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount)
	{
		switch (state) 
		{
			case TIMER_ENUM_TIMER_STATE1:
				TIMER_State1(behavior, submachineState, signal, enumEntryType, entryArray, nArrayCount);
				break;
		}
		return false;
	}
	
	public boolean TIMER_State1(StateBehaviorEnum behavior, StateData submachineState, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount) 
	{
		if (m_StateMachineImpl == null)
			return false;
	
		StateData state = m_StateMachineImpl.GetStateObject(submachineState, StateEnum.TIMER_ENUM_TIMER_STATE1.ordinal());
		switch (behavior) 
		{
			case ENTRY:
				if(state.active_count > 0)
					return false;
				m_timer = StateEnum.TIMER_ENUM_TIMER_STATE1;
				state.IncrementActiveCount();
				TIMER_State1_behavior(StateBehaviorEnum.ENTRY);
						
				TIMER_State1_behavior(StateBehaviorEnum.DO);
			
				if((enumEntryType == EntryTypeEnum.EntryPointEntry || enumEntryType == EntryTypeEnum.DefaultEntry) && state.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, state);
				break;
			case EXIT:
				if(state.active_count == 0)
					return false;
				m_timer = StateEnum.NOSTATE;
				state.DecrementActiveCount();
				TIMER_State1_behavior(StateBehaviorEnum.EXIT);
				m_StateMachineImpl.removeInternalEvent(state);
				break;
		}
	
		return true;
	}

	public boolean TIMER_State1_behavior(StateBehaviorEnum behavior)
	{
		switch (behavior) 
		{
			case ENTRY:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Entry Behavior: TIMER_State1");
			}
			break;
			case DO:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Do Behavior: TIMER_State1");
			}
			break;
			case EXIT:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Exit Behavior: TIMER_State1");
			}
			break;
		}
	
		return true;
	}
	public boolean dispatch(Event event, StateData toState, boolean bCheckOnly)
	{
		if (m_StateMachineImpl == null)
			return false;
		
		boolean bDispatched = false;
		if(toState == null || !toState.IsActiveState() && !bCheckOnly)
			return bDispatched;
		
		switch (StateEnum.values()[toState.state_enum]) 
		{
			case TIMER_VIRTUAL_SUBMACHINESTATE:
				if(event.eventEnum == EventProxy.EventEnum.COMPLETION)
				{
					if(!bCheckOnly)
					{
						m_StateMachineImpl.ReleaseSubmachineState(toState);
						for (int index = m_StateMachineImpl.lstStateData.size() - 1; index >= 0; index--)
						{
							StateData state = m_StateMachineImpl.lstStateData.get(index);
							if (state == toState)
							{
								m_StateMachineImpl.lstStateData.remove(state);
								break;
							}						
						}
						//delete toState;
						toState = null;
					}				
					bDispatched = true;
				}
				break;
			case TIMER_ENUM_TIMER_STATE1:
				switch (event.eventEnum) 
				{
					case ENUM_OK_TICK:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.TIMER_ENUM_STATE1__TO__STATE1_3030, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
				}
				break;
		}
		
		if (!bDispatched && toState != null && toState.parent_state != null && event.eventEnum != EventProxy.EventEnum.COMPLETION)
		{
			bDispatched = dispatch(event, toState.parent_state, true);
			if (bDispatched && !bCheckOnly)
			{
				/*1. Exit the current state; 2. Decrement the active count of the parent state; 3. dispatch the event to parent state*/
				StateProc(StateEnum.values()[toState.state_enum], toState.submachine_state, StateBehaviorEnum.EXIT, null);
				toState.parent_state.DecrementActiveCount();
				dispatch(event, toState.parent_state, false);
				event = null;
			}
		}
		
		return bDispatched;
	}
	
	StateEnum m_timer;
	
	@Override
    public void runStateMachine(String statemachine)
    {
		if(statemachine.equals("TIMER_TIMER"))
		{
			runStateMachine(StateMachineEnum.TIMER_ENUM_TIMER);
			return;
		}
    }
	
	private void runStateMachine(StateMachineEnum statemachine, StateData submachineState, Signal signal)
	{
		runStateMachine(statemachine, submachineState, signal, null, 0);
	}
	
	private void runStateMachine(StateMachineEnum statemachine, StateData submachineState, Signal signal, EntryEnum[] entryArray, int nEntryCount)
	{
		if (m_StateMachineImpl == null)
			return;
		
		if(submachineState == null)
		{
			StateInitialData initialData = new StateInitialData(StateEnum.TIMER_VIRTUAL_SUBMACHINESTATE.ordinal(), StateEnum.NOSTATE.ordinal(), 1, false, "TIMER_VIRTUAL_SUBMACHINESTATE", "", ""); 
			submachineState = new StateData(m_StateMachineImpl, initialData);
			submachineState.IncrementActiveCount();
			m_StateMachineImpl.lstStateData.add(submachineState);
		}
		switch (statemachine) 
		{
			case TIMER_ENUM_TIMER:
				{
					final int nArrayCount = 1;
					StateInitialData[] initialDataArray = 
						{
							new StateInitialData(StateEnum.TIMER_ENUM_TIMER_STATE1.ordinal(), StateEnum.NOSTATE.ordinal(), 0, false, "TIMER_TIMER_State1", "{854A03B4-96F1-4223-91B4-EFF7F24BBD85}", m_sInstanceName)
						};
		
					m_StateMachineImpl.CreateStateObjects(initialDataArray, nArrayCount, submachineState);
				}
				for(int i = 0; i < nEntryCount; i++)
				{
					switch(entryArray[i])
					{
					case TIMER_ENUM_TIMER_INITIAL_829:
						TransitionProc(TransitionEnum.TIMER_ENUM_INITIAL_829__TO__STATE1_3028, signal, submachineState);
						break;
					}
				}
				if(submachineState.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, submachineState);
				break;
		}
	
	}
	
	public void runStateMachine(StateMachineEnum statemachine)
	{
		if (m_StateMachineImpl == null)
			return;
		
		List<StateData> activeStateArray = new ArrayList<StateData>();
		if(m_StateMachineImpl.GetCurrentStates(activeStateArray) > 0)
			return;
		switch (statemachine) 
		{
			case TIMER_ENUM_TIMER:
				{
					final int nArrayCount = 1;
					EntryEnum[] entryArray = {EntryEnum.TIMER_ENUM_TIMER_INITIAL_829};
					runStateMachine(statemachine, null, null, entryArray, nArrayCount);	//submachineState is NULL if run standalone statemachine 
				}
				break;
		}
	}
	
	public void runStateMachines()
	{
		runStateMachine(StateMachineEnum.TIMER_ENUM_TIMER);	
	}


	/* End - EA generated code for StateMachine */
}//end TIMER