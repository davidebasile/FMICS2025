public enum EntryTypeEnum
{
	DefaultEntry,
	ExplicitEntry,
	HistoryEntry,
	EntryPointEntry,
};