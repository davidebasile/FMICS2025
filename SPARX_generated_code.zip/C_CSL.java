import java.util.*;


/**
 * @author Davide Basile (ISTI CNR Italy)
 * @version 1.0
 * @created 17-May-2023 6:32:44 PM
 */
public class C_CSL implements StateMachineContext {

	public int max_receive_timer;
	public int max_send_timer;
	private int receive_timer;
	private int send_timer;
	public SAI SAI;
	public RBC_USER RBC_USER;
	public TIMER TIMER;

	/* Begin - EA generated code for StateMachine */


	enum StateMachineEnum 
	{
		NOSTATEMACHINE,
		C_CSL_ENUM_C_CSL
	};

	enum StateEnum 
	{
		NOSTATE,
		C_CSL_VIRTUAL_SUBMACHINESTATE,
		C_CSL_ENUM_C_CSL_NOCOMMS,
		C_CSL_ENUM_C_CSL_COMMS
	};

	enum TransitionEnum 
	{
		NOTRANSITION,
		C_CSL_ENUM_COMMS__TO__NOCOMMS_2998,
		C_CSL_ENUM_INITIAL_760__TO__NOCOMMS_3000,
		C_CSL_ENUM_COMMS__TO__COMMS_2986,
		C_CSL_ENUM_NOCOMMS__TO__NOCOMMS_2997,
		C_CSL_ENUM_COMMS__TO__COMMS_2989,
		C_CSL_ENUM_COMMS__TO__COMMS_3035,
		C_CSL_ENUM_COMMS__TO__NOCOMMS_2995,
		C_CSL_ENUM_COMMS__TO__COMMS_2991,
		C_CSL_ENUM_COMMS__TO__COMMS_2990,
		C_CSL_ENUM_NOCOMMS__TO__COMMS_2999,
		C_CSL_ENUM_NOCOMMS__TO__NOCOMMS_2993,
		C_CSL_ENUM_COMMS__TO__COMMS_2987,
		C_CSL_ENUM_COMMS__TO__COMMS_2988
	};

	enum EntryEnum
	{
		NOENTRY,
		C_CSL_ENUM_C_CSL_INITIAL_760
	};

	public StateMachineImpl m_StateMachineImpl;	
	
	public C_CSL()
	{
		m_StateMachineImpl = null;
	}
	
	protected void finalize( ) throws Throwable
	{
	}
	
	public C_CSL(ContextManager pManager, String sInstanceName)
	{
		//Initialize Region Variables
		m_c_csl = StateEnum.NOSTATE;	
		m_sInstanceName = sInstanceName;
		m_sType = "C_CSL";
		m_StateMachineImpl = new StateMachineImpl(this, pManager);
	}
	
    public String m_sInstanceName;
    public String m_sType;
	
	public String GetInstanceName()
	{
		return m_sInstanceName;
	}
	
	public String GetTypeName()
	{
		return m_sType;
	}
	
	public boolean defer(Event event, StateData toState)
	{
		if (m_StateMachineImpl == null)
			return false;
		
		boolean bDefer = false;
    
		
		if(!bDefer)
		{
			if(toState.parent_state != null)
			{
				bDefer = defer(event, toState.parent_state);
			}
		}
		return bDefer;
	}

	public void TransitionProc(TransitionEnum transition, Signal signal, StateData submachineState)
	{
		if (m_StateMachineImpl == null)
			return;
		
	
		switch (transition) 
		{
			case C_CSL_ENUM_COMMS__TO__NOCOMMS_2998:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_COMMS__TO__NOCOMMS_2998", "{00E72552-461F-4e49-83BB-34B22A28674B}",m_sInstanceName);
				COMMS__TO__NOCOMMS_2998(signal, submachineState); 
				break;
			case C_CSL_ENUM_INITIAL_760__TO__NOCOMMS_3000:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_Initial_760__TO__NOCOMMS_3000", "{12D1F606-BBC3-456e-B4E9-4BFFE4919C24}",m_sInstanceName);
				Initial_760__TO__NOCOMMS_3000(signal, submachineState); 
				break;
			case C_CSL_ENUM_COMMS__TO__COMMS_2986:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_COMMS__TO__COMMS_2986", "{1C80D0D5-BD07-4863-ACD7-0B520EDEFBFA}",m_sInstanceName);
				COMMS__TO__COMMS_2986(signal, submachineState); 
				break;
			case C_CSL_ENUM_NOCOMMS__TO__NOCOMMS_2997:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_NOCOMMS__TO__NOCOMMS_2997", "{2461E000-DC40-40b2-B5B3-546788E62380}",m_sInstanceName);
				NOCOMMS__TO__NOCOMMS_2997(signal, submachineState); 
				break;
			case C_CSL_ENUM_COMMS__TO__COMMS_2989:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_COMMS__TO__COMMS_2989", "{250B1F40-EB5F-41e4-987F-2062C8F1BE68}",m_sInstanceName);
				COMMS__TO__COMMS_2989(signal, submachineState); 
				break;
			case C_CSL_ENUM_COMMS__TO__COMMS_3035:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_COMMS__TO__COMMS_3035", "{2D7A4AFE-1404-49f2-90E8-39A7A1CBB6D1}",m_sInstanceName);
				COMMS__TO__COMMS_3035(signal, submachineState); 
				break;
			case C_CSL_ENUM_COMMS__TO__NOCOMMS_2995:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_COMMS__TO__NOCOMMS_2995", "{33087BDE-DD54-47f0-AA23-4101149AEEF2}",m_sInstanceName);
				COMMS__TO__NOCOMMS_2995(signal, submachineState); 
				break;
			case C_CSL_ENUM_COMMS__TO__COMMS_2991:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_COMMS__TO__COMMS_2991", "{3545503D-9241-4ddd-ACD9-D19FA73FF94E}",m_sInstanceName);
				COMMS__TO__COMMS_2991(signal, submachineState); 
				break;
			case C_CSL_ENUM_COMMS__TO__COMMS_2990:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_COMMS__TO__COMMS_2990", "{3A3DD7FC-E8BC-4f2f-BCAF-B3B9C4FDDFA8}",m_sInstanceName);
				COMMS__TO__COMMS_2990(signal, submachineState); 
				break;
			case C_CSL_ENUM_NOCOMMS__TO__COMMS_2999:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_NOCOMMS__TO__COMMS_2999", "{5F69A038-6AEA-40d1-8A9A-B41C789A159D}",m_sInstanceName);
				NOCOMMS__TO__COMMS_2999(signal, submachineState); 
				break;
			case C_CSL_ENUM_NOCOMMS__TO__NOCOMMS_2993:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_NOCOMMS__TO__NOCOMMS_2993", "{6228F38E-7844-4391-B7DB-6308DA0AF9D8}",m_sInstanceName);
				NOCOMMS__TO__NOCOMMS_2993(signal, submachineState); 
				break;
			case C_CSL_ENUM_COMMS__TO__COMMS_2987:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_COMMS__TO__COMMS_2987", "{9D8EEDB4-CF0E-44ad-9022-F1D451CEC81A}",m_sInstanceName);
				COMMS__TO__COMMS_2987(signal, submachineState); 
				break;
			case C_CSL_ENUM_COMMS__TO__COMMS_2988:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "C_CSL_COMMS__TO__COMMS_2988", "{D8A72C9B-6005-45f4-84DE-253BBF76F706}",m_sInstanceName);
				COMMS__TO__COMMS_2988(signal, submachineState); 
				break;
		}
	
		m_StateMachineImpl.currentTransition.SetTransition(TransitionEnum.NOTRANSITION.ordinal(), null, "", "","");	
	}
	
	private void COMMS__TO__NOCOMMS_2998_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__NOCOMMS_2998");
	
		this.receive_timer=0;
		this.send_timer=0;
	
		m_StateMachineImpl.m_pManager.SendEvent("OK_TICK",TIMER.m_StateMachineImpl);
		m_StateMachineImpl.m_pManager.SendEvent("RBC_USER_DISCONNECT_INDICATION",RBC_USER.m_StateMachineImpl);
		m_StateMachineImpl.m_pManager.SendEvent("SAI_DISCONNECT_REQUEST",SAI.m_StateMachineImpl);

	}

	private void COMMS__TO__NOCOMMS_2998(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__NOCOMMS_2998_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void Initial_760__TO__NOCOMMS_3000_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: Initial_760__TO__NOCOMMS_3000");
	
	}

	private void Initial_760__TO__NOCOMMS_3000(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(submachineState != null)
			submachineState.IncrementActiveCount();
		Initial_760__TO__NOCOMMS_3000_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_2986_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_2986");
	
	}

	private void COMMS__TO__COMMS_2986(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_2986_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void NOCOMMS__TO__NOCOMMS_2997_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: NOCOMMS__TO__NOCOMMS_2997");
	
	
		m_StateMachineImpl.m_pManager.SendEvent("OK_TICK",TIMER.m_StateMachineImpl);

	}

	private void NOCOMMS__TO__NOCOMMS_2997(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS, submachineState, StateBehaviorEnum.EXIT, null);
		NOCOMMS__TO__NOCOMMS_2997_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_2989_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_2989");
	
		this.send_timer = 0;
		this.receive_timer = this.receive_timer+1;
	
		m_StateMachineImpl.m_pManager.SendEvent("OK_TICK",TIMER.m_StateMachineImpl);
		m_StateMachineImpl.m_pManager.SendEvent("SAI_DATA_REQUEST.sig_sai(LifeSign,nodata)",SAI.m_StateMachineImpl);

	}

	private void COMMS__TO__COMMS_2989(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_2989_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_3035_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_3035");
	
		this.receive_timer=0;

	}

	private void COMMS__TO__COMMS_3035(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_3035_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__NOCOMMS_2995_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__NOCOMMS_2995");
	
		m_StateMachineImpl.m_pManager.SendEvent("RBC_USER_DISCONNECT_INDICATION",RBC_USER.m_StateMachineImpl);
		this.receive_timer=0;
		this.send_timer=0;

	}

	private void COMMS__TO__NOCOMMS_2995(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__NOCOMMS_2995_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_2991_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_2991");
	
		this.send_timer=0;
		m_StateMachineImpl.m_pManager.SendEvent("SAI_DATA_REQUEST.sig_sai(Data,"+signal.parameterValues.get("udata")+")",SAI.m_StateMachineImpl);

	}

	private void COMMS__TO__COMMS_2991(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_2991_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_2990_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_2990");
	
		this.send_timer = this.send_timer+ 1;
		this.receive_timer = this.receive_timer+1;
	
		m_StateMachineImpl.m_pManager.SendEvent("OK_TICK",TIMER.m_StateMachineImpl);
		
	

	}

	private void COMMS__TO__COMMS_2990(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_2990_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void NOCOMMS__TO__COMMS_2999_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: NOCOMMS__TO__COMMS_2999");
	
		m_StateMachineImpl.m_pManager.SendEvent("RBC_USER_CONNECT_INDICATION",RBC_USER.m_StateMachineImpl);

	}

	private void NOCOMMS__TO__COMMS_2999(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS, submachineState, StateBehaviorEnum.EXIT, null);
		NOCOMMS__TO__COMMS_2999_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void NOCOMMS__TO__NOCOMMS_2993_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: NOCOMMS__TO__NOCOMMS_2993");
	
	}

	private void NOCOMMS__TO__NOCOMMS_2993(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS, submachineState, StateBehaviorEnum.EXIT, null);
		NOCOMMS__TO__NOCOMMS_2993_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_2987_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_2987");
	
		this.receive_timer=0;
		 m_StateMachineImpl.m_pManager.SendEvent("RBC_USER_DATA_INDICATION.sig_user("+signal.parameterValues.get("udata")+")",RBC_USER.m_StateMachineImpl);

	}

	private void COMMS__TO__COMMS_2987(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_2987_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_2988_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_2988");
	
		this.receive_timer=0;
		this.send_timer=0;
		m_StateMachineImpl.m_pManager.SendEvent("RBC_USER_CONNECT_INDICATION",RBC_USER.m_StateMachineImpl);

	}

	private void COMMS__TO__COMMS_2988(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_2988_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.C_CSL_ENUM_C_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal)
	{
		return StateProc(state, submachineState, behavior, signal, EntryTypeEnum.DefaultEntry, null, 0);
	}
	
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType)
	{
		return StateProc(state, submachineState, behavior, signal, enumEntryType, null, 0);
	}
	
	public boolean StateProc(int state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, int[] entryArray, int nArrayCount)
    {
		ArrayList<EntryEnum> entryEnumList = new ArrayList<>();
		if (entryArray != null)
		{
			for(int nEntryIndex : entryArray)
			{
				entryEnumList.add(EntryEnum.values()[nEntryIndex]);
			}
		}
        return StateProc(StateEnum.values()[state], submachineState, behavior, signal, enumEntryType, entryEnumList.toArray(new EntryEnum[entryEnumList.size()]), nArrayCount);
    }
	
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount)
	{
		switch (state) 
		{
			case C_CSL_ENUM_C_CSL_NOCOMMS:
				C_CSL_NOCOMMS(behavior, submachineState, signal, enumEntryType, entryArray, nArrayCount);
				break;

			case C_CSL_ENUM_C_CSL_COMMS:
				C_CSL_COMMS(behavior, submachineState, signal, enumEntryType, entryArray, nArrayCount);
				break;
		}
		return false;
	}
	
	public boolean C_CSL_NOCOMMS(StateBehaviorEnum behavior, StateData submachineState, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount) 
	{
		if (m_StateMachineImpl == null)
			return false;
	
		StateData state = m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS.ordinal());
		switch (behavior) 
		{
			case ENTRY:
				if(state.active_count > 0)
					return false;
				m_c_csl = StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS;
				state.IncrementActiveCount();
				C_CSL_NOCOMMS_behavior(StateBehaviorEnum.ENTRY);
						
				C_CSL_NOCOMMS_behavior(StateBehaviorEnum.DO);
			
				if((enumEntryType == EntryTypeEnum.EntryPointEntry || enumEntryType == EntryTypeEnum.DefaultEntry) && state.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, state);
				break;
			case EXIT:
				if(state.active_count == 0)
					return false;
				m_c_csl = StateEnum.NOSTATE;
				state.DecrementActiveCount();
				C_CSL_NOCOMMS_behavior(StateBehaviorEnum.EXIT);
				m_StateMachineImpl.removeInternalEvent(state);
				break;
		}
	
		return true;
	}

	public boolean C_CSL_NOCOMMS_behavior(StateBehaviorEnum behavior)
	{
		switch (behavior) 
		{
			case ENTRY:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Entry Behavior: C_CSL_NOCOMMS");
			}
			break;
			case DO:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Do Behavior: C_CSL_NOCOMMS");
			}
			break;
			case EXIT:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Exit Behavior: C_CSL_NOCOMMS");
			}
			break;
		}
	
		return true;
	}
	public boolean C_CSL_COMMS(StateBehaviorEnum behavior, StateData submachineState, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount) 
	{
		if (m_StateMachineImpl == null)
			return false;
	
		StateData state = m_StateMachineImpl.GetStateObject(submachineState, StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal());
		switch (behavior) 
		{
			case ENTRY:
				if(state.active_count > 0)
					return false;
				m_c_csl = StateEnum.C_CSL_ENUM_C_CSL_COMMS;
				state.IncrementActiveCount();
				C_CSL_COMMS_behavior(StateBehaviorEnum.ENTRY);
						
				C_CSL_COMMS_behavior(StateBehaviorEnum.DO);
			
				if((enumEntryType == EntryTypeEnum.EntryPointEntry || enumEntryType == EntryTypeEnum.DefaultEntry) && state.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, state);
				break;
			case EXIT:
				if(state.active_count == 0)
					return false;
				m_c_csl = StateEnum.NOSTATE;
				state.DecrementActiveCount();
				C_CSL_COMMS_behavior(StateBehaviorEnum.EXIT);
				m_StateMachineImpl.removeInternalEvent(state);
				break;
		}
	
		return true;
	}

	public boolean C_CSL_COMMS_behavior(StateBehaviorEnum behavior)
	{
		switch (behavior) 
		{
			case ENTRY:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Entry Behavior: C_CSL_COMMS");
			}
			break;
			case DO:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Do Behavior: C_CSL_COMMS");
			}
			break;
			case EXIT:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Exit Behavior: C_CSL_COMMS");
			}
			break;
		}
	
		return true;
	}
	public boolean dispatch(Event event, StateData toState, boolean bCheckOnly)
	{
		if (m_StateMachineImpl == null)
			return false;
		
		boolean bDispatched = false;
		if(toState == null || !toState.IsActiveState() && !bCheckOnly)
			return bDispatched;
		
		switch (StateEnum.values()[toState.state_enum]) 
		{
			case C_CSL_VIRTUAL_SUBMACHINESTATE:
				if(event.eventEnum == EventProxy.EventEnum.COMPLETION)
				{
					if(!bCheckOnly)
					{
						m_StateMachineImpl.ReleaseSubmachineState(toState);
						for (int index = m_StateMachineImpl.lstStateData.size() - 1; index >= 0; index--)
						{
							StateData state = m_StateMachineImpl.lstStateData.get(index);
							if (state == toState)
							{
								m_StateMachineImpl.lstStateData.remove(state);
								break;
							}						
						}
						//delete toState;
						toState = null;
					}				
					bDispatched = true;
				}
				break;
			case C_CSL_ENUM_C_CSL_NOCOMMS:
				switch (event.eventEnum) 
				{
					case ENUM_TICK:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_NOCOMMS__TO__NOCOMMS_2997, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_CONNECT_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_NOCOMMS__TO__COMMS_2999, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_RBC_USER_DATA_REQUEST:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_NOCOMMS__TO__NOCOMMS_2993, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_DISCONNECT_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_NOCOMMS__TO__NOCOMMS_2993, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_ERROR_REPORT:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_NOCOMMS__TO__NOCOMMS_2993, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_DATA_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_NOCOMMS__TO__NOCOMMS_2993, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
				}
				break;
			case C_CSL_ENUM_C_CSL_COMMS:
				switch (event.eventEnum) 
				{
					case ENUM_TICK:
						if(this.receive_timer==this.max_receive_timer) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.C_CSL_ENUM_COMMS__TO__NOCOMMS_2998, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						if(this.receive_timer<this.max_receive_timer && this.send_timer==this.max_send_timer) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.C_CSL_ENUM_COMMS__TO__COMMS_2989, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						if(this.receive_timer < this.max_receive_timer && this.send_timer<this.max_send_timer) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.C_CSL_ENUM_COMMS__TO__COMMS_2990, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						break;
					case ENUM_SAI_ERROR_REPORT:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_COMMS__TO__COMMS_2986, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_DATA_INDICATION:
						if(event.signal.parameterValues.get("mtype").equals("LifeSign")) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.C_CSL_ENUM_COMMS__TO__COMMS_3035, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						if(!event.signal.parameterValues.get("mtype").equals("LifeSign")) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.C_CSL_ENUM_COMMS__TO__COMMS_2987, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						break;
					case ENUM_SAI_DISCONNECT_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_COMMS__TO__NOCOMMS_2995, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_RBC_USER_DATA_REQUEST:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_COMMS__TO__COMMS_2991, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_CONNECT_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.C_CSL_ENUM_COMMS__TO__COMMS_2988, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
				}
				break;
		}
		
		if (!bDispatched && toState != null && toState.parent_state != null && event.eventEnum != EventProxy.EventEnum.COMPLETION)
		{
			bDispatched = dispatch(event, toState.parent_state, true);
			if (bDispatched && !bCheckOnly)
			{
				/*1. Exit the current state; 2. Decrement the active count of the parent state; 3. dispatch the event to parent state*/
				StateProc(StateEnum.values()[toState.state_enum], toState.submachine_state, StateBehaviorEnum.EXIT, null);
				toState.parent_state.DecrementActiveCount();
				dispatch(event, toState.parent_state, false);
				event = null;
			}
		}
		
		return bDispatched;
	}
	
	StateEnum m_c_csl;
	
	@Override
    public void runStateMachine(String statemachine)
    {
		if(statemachine.equals("C_CSL_C_CSL"))
		{
			runStateMachine(StateMachineEnum.C_CSL_ENUM_C_CSL);
			return;
		}
    }
	
	private void runStateMachine(StateMachineEnum statemachine, StateData submachineState, Signal signal)
	{
		runStateMachine(statemachine, submachineState, signal, null, 0);
	}
	
	private void runStateMachine(StateMachineEnum statemachine, StateData submachineState, Signal signal, EntryEnum[] entryArray, int nEntryCount)
	{
		if (m_StateMachineImpl == null)
			return;
		
		if(submachineState == null)
		{
			StateInitialData initialData = new StateInitialData(StateEnum.C_CSL_VIRTUAL_SUBMACHINESTATE.ordinal(), StateEnum.NOSTATE.ordinal(), 1, false, "C_CSL_VIRTUAL_SUBMACHINESTATE", "", ""); 
			submachineState = new StateData(m_StateMachineImpl, initialData);
			submachineState.IncrementActiveCount();
			m_StateMachineImpl.lstStateData.add(submachineState);
		}
		switch (statemachine) 
		{
			case C_CSL_ENUM_C_CSL:
				{
					final int nArrayCount = 2;
					StateInitialData[] initialDataArray = 
						{
							new StateInitialData(StateEnum.C_CSL_ENUM_C_CSL_NOCOMMS.ordinal(), StateEnum.NOSTATE.ordinal(), 0, false, "C_CSL_C_CSL_NOCOMMS", "{1CCE5689-2EAC-4c23-ACB6-01C4D7977AF3}", m_sInstanceName),
							new StateInitialData(StateEnum.C_CSL_ENUM_C_CSL_COMMS.ordinal(), StateEnum.NOSTATE.ordinal(), 0, false, "C_CSL_C_CSL_COMMS", "{695CEC1B-A2E9-47cc-A67B-6797CFDB45AC}", m_sInstanceName)
						};
		
					m_StateMachineImpl.CreateStateObjects(initialDataArray, nArrayCount, submachineState);
				}
				for(int i = 0; i < nEntryCount; i++)
				{
					switch(entryArray[i])
					{
					case C_CSL_ENUM_C_CSL_INITIAL_760:
						TransitionProc(TransitionEnum.C_CSL_ENUM_INITIAL_760__TO__NOCOMMS_3000, signal, submachineState);
						break;
					}
				}
				if(submachineState.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, submachineState);
				break;
		}
	
	}
	
	public void runStateMachine(StateMachineEnum statemachine)
	{
		if (m_StateMachineImpl == null)
			return;
		
		List<StateData> activeStateArray = new ArrayList<StateData>();
		if(m_StateMachineImpl.GetCurrentStates(activeStateArray) > 0)
			return;
		switch (statemachine) 
		{
			case C_CSL_ENUM_C_CSL:
				{
					final int nArrayCount = 1;
					EntryEnum[] entryArray = {EntryEnum.C_CSL_ENUM_C_CSL_INITIAL_760};
					runStateMachine(statemachine, null, null, entryArray, nArrayCount);	//submachineState is NULL if run standalone statemachine 
				}
				break;
		}
	}
	
	public void runStateMachines()
	{
		runStateMachine(StateMachineEnum.C_CSL_ENUM_C_CSL);	
	}


	/* End - EA generated code for StateMachine */
}//end C_CSL