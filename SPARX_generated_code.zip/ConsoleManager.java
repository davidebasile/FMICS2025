import java.util.*;


public class ConsoleManager extends ContextManager
{
	C_CSL C_CSL;
	SAI I_SAI;
	SAI C_SAI;
	RBC_USER C_RBC_USER;
	I_CSL I_CSL;
	RBC_USER I_RBC_USER;
	TIMER TIMER;
	public ConsoleManager()
    {
		C_CSL = new C_CSL(this, "C_CSL");
		C_CSL.max_receive_timer = 1;
		C_CSL.max_send_timer = 1;
		lstContext.add(C_CSL.m_StateMachineImpl);
		I_SAI = new SAI(this, "I_SAI");
		lstContext.add(I_SAI.m_StateMachineImpl);
		C_SAI = new SAI(this, "C_SAI");
		lstContext.add(C_SAI.m_StateMachineImpl);
		C_RBC_USER = new RBC_USER(this, "C_RBC_USER");
		lstContext.add(C_RBC_USER.m_StateMachineImpl);
		I_CSL = new I_CSL(this, "I_CSL");
		I_CSL.max_receive_timer = 1;
		I_CSL.max_connect_timer = 3;
		I_CSL.max_send_timer = 1;
		lstContext.add(I_CSL.m_StateMachineImpl);
		I_RBC_USER = new RBC_USER(this, "I_RBC_USER");
		lstContext.add(I_RBC_USER.m_StateMachineImpl);
		TIMER = new TIMER(this, "TIMER");
		lstContext.add(TIMER.m_StateMachineImpl);
		//setup instance associations
		I_CSL.RBC_USER = I_RBC_USER;
		C_CSL.SAI = C_SAI;
		I_CSL.TIMER = TIMER;
		C_CSL.TIMER = TIMER;
		I_CSL.SAI = I_SAI;
		C_CSL.RBC_USER = C_RBC_USER;
    }
	
	public void ClearInstance(String instanceStr)
	{
		if(instanceStr != null && instanceStr.compareTo("C_CSL") == 0)
			C_CSL = null;
		if(instanceStr != null && instanceStr.compareTo("I_SAI") == 0)
			I_SAI = null;
		if(instanceStr != null && instanceStr.compareTo("C_SAI") == 0)
			C_SAI = null;
		if(instanceStr != null && instanceStr.compareTo("C_RBC_USER") == 0)
			C_RBC_USER = null;
		if(instanceStr != null && instanceStr.compareTo("I_CSL") == 0)
			I_CSL = null;
		if(instanceStr != null && instanceStr.compareTo("I_RBC_USER") == 0)
			I_RBC_USER = null;
		if(instanceStr != null && instanceStr.compareTo("TIMER") == 0)
			TIMER = null;
	}
	
    public void Run()
    {
		simulationStartTime = System.currentTimeMillis();
	
		boolean bContinue=true;
	    RunAllStateMachines();
	    while(bContinue)
	    {
			//recall all completion events
            EvaluateCommandString("stepall");
            
		    String sIn = "";
            try{
                java.io.BufferedReader bufferRead = new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
                sIn = bufferRead.readLine();
            }
            catch(java.io.IOException e)
            {
                e.printStackTrace();
            }
			bContinue = EvaluateCommandString(sIn);
	    }
    }
		
    public static void main(String[] args)
    {
		EventProxy.initializeStrings();
        ConsoleManager manager = new ConsoleManager();
        manager.initialize();
        manager.Run();
		System.exit(0);
    } 
};