public class Event 
{
	public Event(EventProxy.EventEnum eventEnum_, Signal signal_)
	{
		eventEnum = eventEnum_;
		signal = signal_;
	}
	
	protected void finalize( ) throws Throwable
	{
	}
	
	public EventProxy.EventEnum eventEnum;
	public Signal signal;
};