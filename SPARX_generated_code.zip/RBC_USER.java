import java.util.*;


/**
 * The RBC_USER class is only a stub.
 * @author DavideDavide Basile (ISTI CNR Italy)
 * @version 1.0
 * @created 17-May-2023 6:32:45 PM
 */
public class RBC_USER implements StateMachineContext {

	/* Begin - EA generated code for StateMachine */


	enum StateMachineEnum 
	{
		NOSTATEMACHINE,
		RBC_USER_ENUM_RBC_USER
	};

	enum StateEnum 
	{
		NOSTATE,
		RBC_USER_VIRTUAL_SUBMACHINESTATE,
		RBC_USER_ENUM_RBC_USER_STUB
	};

	enum TransitionEnum 
	{
		NOTRANSITION,
		RBC_USER_ENUM_STUB__TO__STUB_206,
		RBC_USER_ENUM_INITIAL_179__TO__STUB_205
	};

	enum EntryEnum
	{
		NOENTRY,
		RBC_USER_ENUM_RBC_USER_INITIAL_179
	};

	public StateMachineImpl m_StateMachineImpl;	
	
	public RBC_USER()
	{
		m_StateMachineImpl = null;
	}
	
	protected void finalize( ) throws Throwable
	{
	}
	
	public RBC_USER(ContextManager pManager, String sInstanceName)
	{
		//Initialize Region Variables
		m_rbc_user = StateEnum.NOSTATE;	
		m_sInstanceName = sInstanceName;
		m_sType = "RBC_USER";
		m_StateMachineImpl = new StateMachineImpl(this, pManager);
	}
	
    public String m_sInstanceName;
    public String m_sType;
	
	public String GetInstanceName()
	{
		return m_sInstanceName;
	}
	
	public String GetTypeName()
	{
		return m_sType;
	}
	
	public boolean defer(Event event, StateData toState)
	{
		if (m_StateMachineImpl == null)
			return false;
		
		boolean bDefer = false;
    
		
		if(!bDefer)
		{
			if(toState.parent_state != null)
			{
				bDefer = defer(event, toState.parent_state);
			}
		}
		return bDefer;
	}

	public void TransitionProc(TransitionEnum transition, Signal signal, StateData submachineState)
	{
		if (m_StateMachineImpl == null)
			return;
		
	
		switch (transition) 
		{
			case RBC_USER_ENUM_STUB__TO__STUB_206:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "RBC_USER_Stub__TO__Stub_206", "{A1764B3C-6EB3-44f9-BB3F-54C607425400}",m_sInstanceName);
				Stub__TO__Stub_206(signal, submachineState); 
				break;
			case RBC_USER_ENUM_INITIAL_179__TO__STUB_205:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "RBC_USER_Initial_179__TO__Stub_205", "{C06A73AF-1B3E-483a-BCA7-E893446CA1D8}",m_sInstanceName);
				Initial_179__TO__Stub_205(signal, submachineState); 
				break;
		}
	
		m_StateMachineImpl.currentTransition.SetTransition(TransitionEnum.NOTRANSITION.ordinal(), null, "", "","");	
	}
	
	private void Stub__TO__Stub_206_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: Stub__TO__Stub_206");
	
	}

	private void Stub__TO__Stub_206(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		Stub__TO__Stub_206_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
	}
	private void Initial_179__TO__Stub_205_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: Initial_179__TO__Stub_205");
	
	}

	private void Initial_179__TO__Stub_205(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(submachineState != null)
			submachineState.IncrementActiveCount();
		Initial_179__TO__Stub_205_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.RBC_USER_ENUM_RBC_USER_STUB, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal)
	{
		return StateProc(state, submachineState, behavior, signal, EntryTypeEnum.DefaultEntry, null, 0);
	}
	
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType)
	{
		return StateProc(state, submachineState, behavior, signal, enumEntryType, null, 0);
	}
	
	public boolean StateProc(int state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, int[] entryArray, int nArrayCount)
    {
		ArrayList<EntryEnum> entryEnumList = new ArrayList<>();
		if (entryArray != null)
		{
			for(int nEntryIndex : entryArray)
			{
				entryEnumList.add(EntryEnum.values()[nEntryIndex]);
			}
		}
        return StateProc(StateEnum.values()[state], submachineState, behavior, signal, enumEntryType, entryEnumList.toArray(new EntryEnum[entryEnumList.size()]), nArrayCount);
    }
	
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount)
	{
		switch (state) 
		{
			case RBC_USER_ENUM_RBC_USER_STUB:
				RBC_USER_Stub(behavior, submachineState, signal, enumEntryType, entryArray, nArrayCount);
				break;
		}
		return false;
	}
	
	public boolean RBC_USER_Stub(StateBehaviorEnum behavior, StateData submachineState, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount) 
	{
		if (m_StateMachineImpl == null)
			return false;
	
		StateData state = m_StateMachineImpl.GetStateObject(submachineState, StateEnum.RBC_USER_ENUM_RBC_USER_STUB.ordinal());
		switch (behavior) 
		{
			case ENTRY:
				if(state.active_count > 0)
					return false;
				m_rbc_user = StateEnum.RBC_USER_ENUM_RBC_USER_STUB;
				state.IncrementActiveCount();
				RBC_USER_Stub_behavior(StateBehaviorEnum.ENTRY);
						
				RBC_USER_Stub_behavior(StateBehaviorEnum.DO);
			
				if((enumEntryType == EntryTypeEnum.EntryPointEntry || enumEntryType == EntryTypeEnum.DefaultEntry) && state.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, state);
				break;
			case EXIT:
				if(state.active_count == 0)
					return false;
				m_rbc_user = StateEnum.NOSTATE;
				state.DecrementActiveCount();
				RBC_USER_Stub_behavior(StateBehaviorEnum.EXIT);
				m_StateMachineImpl.removeInternalEvent(state);
				break;
		}
	
		return true;
	}

	public boolean RBC_USER_Stub_behavior(StateBehaviorEnum behavior)
	{
		switch (behavior) 
		{
			case ENTRY:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Entry Behavior: RBC_USER_Stub");
			}
			break;
			case DO:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Do Behavior: RBC_USER_Stub");
			}
			break;
			case EXIT:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Exit Behavior: RBC_USER_Stub");
			}
			break;
		}
	
		return true;
	}
	public boolean dispatch(Event event, StateData toState, boolean bCheckOnly)
	{
		if (m_StateMachineImpl == null)
			return false;
		
		boolean bDispatched = false;
		if(toState == null || !toState.IsActiveState() && !bCheckOnly)
			return bDispatched;
		
		switch (StateEnum.values()[toState.state_enum]) 
		{
			case RBC_USER_VIRTUAL_SUBMACHINESTATE:
				if(event.eventEnum == EventProxy.EventEnum.COMPLETION)
				{
					if(!bCheckOnly)
					{
						m_StateMachineImpl.ReleaseSubmachineState(toState);
						for (int index = m_StateMachineImpl.lstStateData.size() - 1; index >= 0; index--)
						{
							StateData state = m_StateMachineImpl.lstStateData.get(index);
							if (state == toState)
							{
								m_StateMachineImpl.lstStateData.remove(state);
								break;
							}						
						}
						//delete toState;
						toState = null;
					}				
					bDispatched = true;
				}
				break;
			case RBC_USER_ENUM_RBC_USER_STUB:
				switch (event.eventEnum) 
				{
					case ENUM_RBC_USER_CONNECT_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.RBC_USER_ENUM_STUB__TO__STUB_206, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_RBC_USER_DATA_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.RBC_USER_ENUM_STUB__TO__STUB_206, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_RBC_USER_DISCONNECT_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.RBC_USER_ENUM_STUB__TO__STUB_206, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
				}
				break;
		}
		
		if (!bDispatched && toState != null && toState.parent_state != null && event.eventEnum != EventProxy.EventEnum.COMPLETION)
		{
			bDispatched = dispatch(event, toState.parent_state, true);
			if (bDispatched && !bCheckOnly)
			{
				/*1. Exit the current state; 2. Decrement the active count of the parent state; 3. dispatch the event to parent state*/
				StateProc(StateEnum.values()[toState.state_enum], toState.submachine_state, StateBehaviorEnum.EXIT, null);
				toState.parent_state.DecrementActiveCount();
				dispatch(event, toState.parent_state, false);
				event = null;
			}
		}
		
		return bDispatched;
	}
	
	StateEnum m_rbc_user;
	
	@Override
    public void runStateMachine(String statemachine)
    {
		if(statemachine.equals("RBC_USER_RBC_USER"))
		{
			runStateMachine(StateMachineEnum.RBC_USER_ENUM_RBC_USER);
			return;
		}
    }
	
	private void runStateMachine(StateMachineEnum statemachine, StateData submachineState, Signal signal)
	{
		runStateMachine(statemachine, submachineState, signal, null, 0);
	}
	
	private void runStateMachine(StateMachineEnum statemachine, StateData submachineState, Signal signal, EntryEnum[] entryArray, int nEntryCount)
	{
		if (m_StateMachineImpl == null)
			return;
		
		if(submachineState == null)
		{
			StateInitialData initialData = new StateInitialData(StateEnum.RBC_USER_VIRTUAL_SUBMACHINESTATE.ordinal(), StateEnum.NOSTATE.ordinal(), 1, false, "RBC_USER_VIRTUAL_SUBMACHINESTATE", "", ""); 
			submachineState = new StateData(m_StateMachineImpl, initialData);
			submachineState.IncrementActiveCount();
			m_StateMachineImpl.lstStateData.add(submachineState);
		}
		switch (statemachine) 
		{
			case RBC_USER_ENUM_RBC_USER:
				{
					final int nArrayCount = 1;
					StateInitialData[] initialDataArray = 
						{
							new StateInitialData(StateEnum.RBC_USER_ENUM_RBC_USER_STUB.ordinal(), StateEnum.NOSTATE.ordinal(), 0, false, "RBC_USER_RBC_USER_Stub", "{D2DC4166-30A2-465d-8EFC-305566776B5B}", m_sInstanceName)
						};
		
					m_StateMachineImpl.CreateStateObjects(initialDataArray, nArrayCount, submachineState);
				}
				for(int i = 0; i < nEntryCount; i++)
				{
					switch(entryArray[i])
					{
					case RBC_USER_ENUM_RBC_USER_INITIAL_179:
						TransitionProc(TransitionEnum.RBC_USER_ENUM_INITIAL_179__TO__STUB_205, signal, submachineState);
						break;
					}
				}
				if(submachineState.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, submachineState);
				break;
		}
	
	}
	
	public void runStateMachine(StateMachineEnum statemachine)
	{
		if (m_StateMachineImpl == null)
			return;
		
		List<StateData> activeStateArray = new ArrayList<StateData>();
		if(m_StateMachineImpl.GetCurrentStates(activeStateArray) > 0)
			return;
		switch (statemachine) 
		{
			case RBC_USER_ENUM_RBC_USER:
				{
					final int nArrayCount = 1;
					EntryEnum[] entryArray = {EntryEnum.RBC_USER_ENUM_RBC_USER_INITIAL_179};
					runStateMachine(statemachine, null, null, entryArray, nArrayCount);	//submachineState is NULL if run standalone statemachine 
				}
				break;
		}
	}
	
	public void runStateMachines()
	{
		runStateMachine(StateMachineEnum.RBC_USER_ENUM_RBC_USER);	
	}


	/* End - EA generated code for StateMachine */
}//end RBC_USER