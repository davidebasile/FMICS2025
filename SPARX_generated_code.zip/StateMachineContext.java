public interface StateMachineContext
{
	public String GetInstanceName();
	public String GetTypeName();
	
	public void runStateMachines();
	public void runStateMachine(String statemachine);
	public boolean dispatch(Event event_, StateData toState, boolean bCheckOnly);
	public boolean StateProc(int state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, int[] entryArray, int nArrayCount);
	public boolean defer(Event event_, StateData toState);
};