import java.util.List;


public class EventProxy 
{
	public enum SignalEnum 
	{
		EMPTY,
		ENUM_SIG_USER,
		ENUM_SIG_SAI
	};
	
	public enum EventEnum 
	{
		COMPLETION,
		ENUM_RBC_USER_DATA_INDICATION,
		ENUM_RBC_USER_DISCONNECT_INDICATION,
		ENUM_SAI_CONNECT_REQUEST,
		ENUM_OK_TICK,
		ENUM_SAI_DISCONNECT_REQUEST,
		ENUM_SAI_ERROR_REPORT,
		ENUM_SAI_DATA_INDICATION,
		ENUM_SAI_CONNECT_CONFIRM,
		ENUM_TICK,
		ENUM_SAI_CONNECT_INDICATION,
		ENUM_SAI_DISCONNECT_INDICATION,
		ENUM_RBC_USER_DATA_REQUEST,
		ENUM_SAI_DATA_REQUEST,
		ENUM_RBC_USER_CONNECT_INDICATION
	};
	
	public static class sig_user extends Signal 
	{
		public sig_user() 
		{ }
		public sig_user(List<String> lstArguments)
		{
			signalEnum = SignalEnum.ENUM_SIG_USER;
			//fill signal attributes for trace purpose
			parameters.add("udata");
			//assign argument to attribute
			int nIndex = 0;
			String argument;
		
			// assign value for "udata:String"
			argument = lstArguments.get(nIndex++);
			udata = argument;
			parameterValues.put("udata", argument);
		}
	
		public String udata;
	};
	public static class sig_sai extends Signal 
	{
		public sig_sai() 
		{ }
		public sig_sai(List<String> lstArguments)
		{
			signalEnum = SignalEnum.ENUM_SIG_SAI;
			//fill signal attributes for trace purpose
			parameters.add("mtype");
			parameters.add("udata");
			//assign argument to attribute
			int nIndex = 0;
			String argument;
		
			// assign value for "mtype:String"
			argument = lstArguments.get(nIndex++);
			mtype = argument;
			parameterValues.put("mtype", argument);
			// assign value for "udata:String"
			argument = lstArguments.get(nIndex++);
			udata = argument;
			parameterValues.put("udata", argument);
		}
	
		public String mtype;
		public String udata;
	};
	
	public static Signal GetSignalInstance(String signalStr, List<String> arguments)
	{
		Signal signal = null;
		while (true)
		{
			if(signalStr != null && signalStr.equals("sig_user"))
			{
				signal = new EventProxy.sig_user(arguments);
				break;
			}
			if(signalStr != null && signalStr.equals("sig_sai"))
			{
				signal = new EventProxy.sig_sai(arguments);
				break;
			}
			break;
		}
		return signal;
	}
	
	public static void initializeStrings()
	{
		StringTable.stringTable.mapStringToEventEnum.put("RBC_USER_DATA_INDICATION", EventProxy.EventEnum.ENUM_RBC_USER_DATA_INDICATION);
		StringTable.stringTable.mapStringToEventEnum.put("RBC_USER_DISCONNECT_INDICATION", EventProxy.EventEnum.ENUM_RBC_USER_DISCONNECT_INDICATION);
		StringTable.stringTable.mapStringToEventEnum.put("SAI_CONNECT_REQUEST", EventProxy.EventEnum.ENUM_SAI_CONNECT_REQUEST);
		StringTable.stringTable.mapStringToEventEnum.put("OK_TICK", EventProxy.EventEnum.ENUM_OK_TICK);
		StringTable.stringTable.mapStringToEventEnum.put("SAI_DISCONNECT_REQUEST", EventProxy.EventEnum.ENUM_SAI_DISCONNECT_REQUEST);
		StringTable.stringTable.mapStringToEventEnum.put("SAI_ERROR_REPORT", EventProxy.EventEnum.ENUM_SAI_ERROR_REPORT);
		StringTable.stringTable.mapStringToEventEnum.put("SAI_DATA_INDICATION", EventProxy.EventEnum.ENUM_SAI_DATA_INDICATION);
		StringTable.stringTable.mapStringToEventEnum.put("SAI_CONNECT_CONFIRM", EventProxy.EventEnum.ENUM_SAI_CONNECT_CONFIRM);
		StringTable.stringTable.mapStringToEventEnum.put("TICK", EventProxy.EventEnum.ENUM_TICK);
		StringTable.stringTable.mapStringToEventEnum.put("SAI_CONNECT_INDICATION", EventProxy.EventEnum.ENUM_SAI_CONNECT_INDICATION);
		StringTable.stringTable.mapStringToEventEnum.put("SAI_DISCONNECT_INDICATION", EventProxy.EventEnum.ENUM_SAI_DISCONNECT_INDICATION);
		StringTable.stringTable.mapStringToEventEnum.put("RBC_USER_DATA_REQUEST", EventProxy.EventEnum.ENUM_RBC_USER_DATA_REQUEST);
		StringTable.stringTable.mapStringToEventEnum.put("SAI_DATA_REQUEST", EventProxy.EventEnum.ENUM_SAI_DATA_REQUEST);
		StringTable.stringTable.mapStringToEventEnum.put("RBC_USER_CONNECT_INDICATION", EventProxy.EventEnum.ENUM_RBC_USER_CONNECT_INDICATION);	
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_RBC_USER_DATA_INDICATION, "RBC_USER_DATA_INDICATION");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_RBC_USER_DISCONNECT_INDICATION, "RBC_USER_DISCONNECT_INDICATION");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_SAI_CONNECT_REQUEST, "SAI_CONNECT_REQUEST");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_OK_TICK, "OK_TICK");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_SAI_DISCONNECT_REQUEST, "SAI_DISCONNECT_REQUEST");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_SAI_ERROR_REPORT, "SAI_ERROR_REPORT");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_SAI_DATA_INDICATION, "SAI_DATA_INDICATION");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_SAI_CONNECT_CONFIRM, "SAI_CONNECT_CONFIRM");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_TICK, "TICK");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_SAI_CONNECT_INDICATION, "SAI_CONNECT_INDICATION");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_SAI_DISCONNECT_INDICATION, "SAI_DISCONNECT_INDICATION");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_RBC_USER_DATA_REQUEST, "RBC_USER_DATA_REQUEST");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_SAI_DATA_REQUEST, "SAI_DATA_REQUEST");
		StringTable.stringTable.mapEventEnumToString.put(EventProxy.EventEnum.ENUM_RBC_USER_CONNECT_INDICATION, "RBC_USER_CONNECT_INDICATION");
		StringTable.stringTable.mapSignalEnumToString.put(EventProxy.SignalEnum.ENUM_SIG_USER, "sig_user");
		StringTable.stringTable.mapSignalEnumToString.put(EventProxy.SignalEnum.ENUM_SIG_SAI, "sig_sai");
		StringTable.stringTable.mapNameToGuid.put("RBC_USER_DATA_INDICATION", "{1AF69AFE-D51A-4933-B34B-F0E5BC4A2F73}");
		StringTable.stringTable.mapNameToGuid.put("RBC_USER_DISCONNECT_INDICATION", "{4DA6A2E0-925E-4993-874E-076C35A3201D}");
		StringTable.stringTable.mapNameToGuid.put("SAI_CONNECT_REQUEST", "{6E743671-14BC-4ad1-8565-34B80E290430}");
		StringTable.stringTable.mapNameToGuid.put("OK_TICK", "{73BEC9DF-1984-4220-AA15-E6B04C0BEA77}");
		StringTable.stringTable.mapNameToGuid.put("SAI_DISCONNECT_REQUEST", "{7871EB5B-CEB6-473d-8047-2228EF06CF87}");
		StringTable.stringTable.mapNameToGuid.put("SAI_ERROR_REPORT", "{9E353955-74E3-4458-BBCB-6734AD4C136C}");
		StringTable.stringTable.mapNameToGuid.put("SAI_DATA_INDICATION", "{AF4BC8B0-EC94-4fcb-8C8E-D0CCE9B5C396}");
		StringTable.stringTable.mapNameToGuid.put("SAI_CONNECT_CONFIRM", "{B9EBA244-A8D5-4513-92DA-D279F4BBAE7E}");
		StringTable.stringTable.mapNameToGuid.put("TICK", "{C99DB152-F44F-4d4b-9170-4B1EDEF2FB47}");
		StringTable.stringTable.mapNameToGuid.put("SAI_CONNECT_INDICATION", "{CEDB3DE3-FC21-44db-924D-CDA5A8BC1E7E}");
		StringTable.stringTable.mapNameToGuid.put("SAI_DISCONNECT_INDICATION", "{CFB7D272-52F5-490e-969D-3E9BDCDCB897}");
		StringTable.stringTable.mapNameToGuid.put("RBC_USER_DATA_REQUEST", "{D4069B1D-BA7B-423f-8DCE-08534B72AE4E}");
		StringTable.stringTable.mapNameToGuid.put("SAI_DATA_REQUEST", "{F462F73E-D205-426d-8194-5DB3F04AE58C}");
		StringTable.stringTable.mapNameToGuid.put("RBC_USER_CONNECT_INDICATION", "{FABD5439-AF92-48ec-A11D-2DE705B7A84D}");
	}
};