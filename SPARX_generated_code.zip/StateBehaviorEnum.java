public enum StateBehaviorEnum 
{
	ENTRY,
	DO,
	EXIT,
};