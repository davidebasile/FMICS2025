import java.util.*;
public class StateMachineImpl
{
	// Owner StateMachineContext instance
	public StateMachineContext instance;
	
    public ContextManager m_pManager;
	public TransitionData currentTransition = new TransitionData();
	public List<StateData> lstStateData = new ArrayList<StateData>();
	public List<InternalEventData> lstDeferredInternalEvents = new ArrayList<InternalEventData>();		//in order to simulate concurrent in a liner way
	public List<Event> eventPool = new ArrayList<Event>();
	public boolean bTerminate;	
	
	public StateMachineImpl(StateMachineContext pInstance, ContextManager pManager)
	{
		this.instance = pInstance;		
		m_pManager = pManager;
	}
	
	protected void finalize( ) throws Throwable
	{
		for (int index = 0; index < lstStateData.size(); )
		{
			StateData state = lstStateData.get(index);
			if (state != null)
			{
				boolean bReleasedSomething = ReleaseSubmachineState(state);
				if (bReleasedSomething)
					index = 0;
				else
					index++;
			}			
		}
	}
		
	public boolean IsTerminated()
	{
		return bTerminate;
	}
	
	public String GetInstanceName()
	{
		if (instance != null)
			return instance.GetInstanceName();
		
		return "";
	}
	
	public String GetTypeName()
	{
		if (instance != null)
			return instance.GetTypeName();
		
		return "";
	}
	
	public List<StateData> GetStateData()
	{
		return lstStateData;
	}	
	public ContextManager GetManager()
	{
		return m_pManager;
	}
	
	public boolean StateProc(int state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, int[] entryArray, int nArrayCount)
	{
		if (instance != null)
			return instance.StateProc(state, submachineState, behavior, signal, enumEntryType, entryArray, nArrayCount);
		
		return false;
	}
	public void runStateMachines()
	{
		if (instance != null)
			instance.runStateMachines();
	}
	
	public void runStateMachine(String statemachine)
	{
		if (instance != null)
            instance.runStateMachine(statemachine);
	}
	
	public void initializeStateMachine()
	{
		bTerminate = false;
	}
	
	public StateData GetStateObject(StateData submachineState, int stateEnum)
	{
		if (stateEnum == 0)
			return null;
		
		for (int index = 0; index < lstStateData.size(); index++)
		{
			StateData state = lstStateData.get(index);
			
			if(state != null && state.submachine_state == submachineState && state.state_enum == stateEnum)
			{
				return state;
			}					
		}
		
		return null;
	}
	
	public String getEventFullString(Event event)
	{
		if(event == null)
		{
			return "";
		}
		String eventStr = "";
		if (StringTable.stringTable.mapEventEnumToString.containsKey(event.eventEnum))
		{
			eventStr = StringTable.stringTable.mapEventEnumToString.get(event.eventEnum);
			if(event.signal != null) {
				if (StringTable.stringTable.mapSignalEnumToString.containsKey(event.signal.signalEnum))
				{
					eventStr += "." + StringTable.stringTable.mapSignalEnumToString.get(event.signal.signalEnum);
				}
				
				if(event.signal.parameters.size() > 0)
				{
					String signalValues = "(";
					for (int i = 0; i < event.signal.parameters.size(); i++) {
						String signalAttributeName = event.signal.parameters.get(i);
						String signalAttributeValue = "undefined";
						if (event.signal.parameterValues.containsKey(signalAttributeName))
						{
							signalAttributeValue = event.signal.parameterValues.get(signalAttributeName);
						}
						
						if(i < event.signal.parameters.size() - 1)
						{
							signalValues += signalAttributeName + ":" + signalAttributeValue + ", ";
						}
						else
						{
							signalValues += signalAttributeName + ":" + signalAttributeValue;
						}
					}
					signalValues += ")";
					eventStr += signalValues;
				}
			}
		}		
		return eventStr;
	};
	
	public void CreateStateObjects(StateInitialData[] initialDataArray, int nArrayCount, StateData submachineState)
	{
		for (int i = 0; i < nArrayCount; i++)
		{
			StateInitialData initialData = initialDataArray[i];
			
			StateData parentState = GetStateObject(submachineState, initialData.parent_state_enum);
			if (parentState == null)
			{
				parentState = submachineState;
			}
			
			StateData state = GetStateObject(submachineState, initialData.state_enum);
			if (state == null)
			{
				state = new StateData(this, initialData);
				lstStateData.add(state);
			}
			
			state.parent_state = parentState;
			state.submachine_state = submachineState;
		}
	}
	
	public boolean ReleaseSubmachineState(StateData submachineState)
	{
		boolean bReleasedSomething = false;
		for (int index = 0; index < lstStateData.size(); )
		{
			StateData state = lstStateData.get(index);
			if (state != null && state.submachine_state == submachineState)
			{
				lstStateData.remove(index);
				bReleasedSomething = true;
				ReleaseSubmachineState(state);
				// delete state;
				state = null;
			}
			else
				index++;
		}
		return bReleasedSomething;
	}
	
	public int GetCurrentStates(List<StateData> activeStates)
	{
		for (int index = 0; index < lstStateData.size(); index++)
		{
			StateData state = lstStateData.get(index);
			
			if (state != null && state.IsActiveState())
			{
				activeStates.add(state);
			}
		}
		return activeStates.size();
	}
	
	public boolean recallOneInternalEvent()
	{
		if(lstDeferredInternalEvents.size() > 0)
		{
			InternalEventData eventData = lstDeferredInternalEvents.get(0);
			lstDeferredInternalEvents.remove(0);
			if (eventData != null)
			{
				GlobalFuncs.trace("[" + GetInstanceName() + ":" + GetTypeName() + "] Completion: " + eventData.state.state_name);
				if (dispatch(eventData.event, eventData.state))
					return true;
			}
		}
		return false;
	}
	
	public void deferInternalEvent(EventProxy.EventEnum eventEnum, Signal signal, StateData state)
	{
		lstDeferredInternalEvents.add(new InternalEventData(new Event(eventEnum, signal), state));
	}
	
	public void removeInternalEvent(StateData state)
	{
		int count = lstDeferredInternalEvents.size();
		for (int i = (count - 1); i >= 0; i--)
		{
			InternalEventData internalEventData = lstDeferredInternalEvents.get(i);
			if (internalEventData != null && internalEventData.state == state)
			{
				lstDeferredInternalEvents.remove(i);
				//delete internalEventData;
				internalEventData = null;
			}
		}
	}
	
	public void DumpActiveCnt()
	{
		GlobalFuncs.trace("state/initial active count for [" + GetInstanceName() + ":" + GetTypeName() + "]:");
		
		for (int index = 0; index < lstStateData.size(); index++)
		{
			StateData state = lstStateData.get(index);
			if (state != null && state.state_name.indexOf("VIRTUAL_SUBMACHINESTATE") == -1)
			{
				if (state.submachine_state != null && state.submachine_state.state_name.indexOf("VIRTUAL_SUBMACHINESTATE") == -1)
				{
					GlobalFuncs.trace("    " + state.active_count + ", " + state.state_name + ", called by:" + state.submachine_state.state_name);
				}
				else
				{
					GlobalFuncs.trace("    " + state.active_count + ", " + state.state_name);
				}
			}		
		}
		
		DumpEvents();
	}

	public void DoDeepHistory(StateData submachineState, int history)
	{
		StateProc(history, submachineState, StateBehaviorEnum.ENTRY, null, EntryTypeEnum.HistoryEntry, null, 0);
		StateData historyObject = GetStateObject(submachineState, history);
		if (historyObject == null)
			return;	//should not happen
		
		for (int i = 0; i < historyObject.region_count; i++)
		{
			int nextHistory = historyObject.historyArray[i];
			if (nextHistory != 0)
			{
				historyObject.IncrementActiveCount();
				if (historyObject.isSubmachineState)
					DoDeepHistory(historyObject, nextHistory);
				else
					DoDeepHistory(submachineState, nextHistory);
			}
		}
	}
	
	public void DumpEvents()
	{
		if(eventPool.size() == 0)
			return;
		
		GlobalFuncs.trace("Event Pool: [");
		
		for (int index = 0; index < eventPool.size(); index++)
		{
			Event event = eventPool.get(index);
			
			String eventFullString = getEventFullString(event);
			if(eventFullString != "")
			{
				GlobalFuncs.trace("    " + eventFullString + ",");
			}
		}
		GlobalFuncs.trace("]");
	}

	
	public void EventOccurance(EventProxy.EventEnum eventEnum, Signal signal)
	{
		Event event = new Event(eventEnum, signal);
		eventPool.add(event);
		
		String eventFullString = getEventFullString(event);
		if(eventFullString != "")
		{
			GlobalFuncs.trace("[" + GetInstanceName() + ":" + GetTypeName() + "] Event Queued: " + eventFullString);
		}
	}

	
	public void recall()
	{
		for (int i = 0; i < eventPool.size(); )
		{
			Event e = eventPool.get(i);
			if (defer(e) == true)
			{
				i++;
			}
			else
			{
				String eventFullString = getEventFullString(e);
				if(eventFullString != "")
				{
					GlobalFuncs.trace("[" + GetInstanceName() + ":" + GetTypeName() + "] Event Dispatched: " + eventFullString);
				}
				
				eventPool.remove(i);
				if (dispatch(e))
					break;
			} 
		}
	}
	
	public boolean defer(Event _event)
	{
		if (_event.eventEnum == EventProxy.EventEnum.COMPLETION)
			return false;
			
		List<StateData> activeStates = new ArrayList<StateData>();
		int nCurrentStateCount = GetCurrentStates(activeStates);
		
		boolean bDeferred = false;
		for (int index = 0; index < activeStates.size(); index++)
		{
			StateData activeState = activeStates.get(index);
			boolean bDeferredToState = defer(_event, activeState);
			if (bDeferredToState)
			{
				bDeferred = true;
				break;
			}            
		}
		return bDeferred;
	}

	
	public boolean defer(Event _event, StateData toState)
	{
		if (instance != null)
			return instance.defer(_event, toState);
			
		return false;
	}

	public boolean dispatch(String eventStr)
	{
		EventData eventData = new EventData();
		GlobalFuncs.ParseEventString(eventStr, eventData);
		Signal signal = EventProxy.GetSignalInstance(eventData.signalStr, eventData.arguments);
		
		boolean returnVal = false;
		if (StringTable.stringTable.mapStringToEventEnum.containsKey(eventData.evtStr))
			returnVal = dispatch(StringTable.stringTable.mapStringToEventEnum.get(eventData.evtStr), signal);
			
		return returnVal;
	}

	public boolean dispatch(EventProxy.EventEnum eventEnum, Signal signal)
	{
		return dispatch(new Event(eventEnum, signal));
	}

	public boolean dispatch(Event _event)
	{
		boolean bDispatched = false;
		
		List<StateData> activeStates = new ArrayList<StateData>();
		int nCurrentStateCount = GetCurrentStates(activeStates);
		
		for (int index = 0; index < activeStates.size(); index++)
		{
			StateData activeState = activeStates.get(index);
			boolean bDispatchedToState = dispatch(_event, activeState, false);
			if (bDispatchedToState)
				bDispatched = true;
		}
		
		return bDispatched;
	}

	public boolean dispatch(Event event_, StateData toState)
	{
		return dispatch(event_, toState, false);
	}

	// call back to StateMachineContext instance method.
	public boolean dispatch(Event _event, StateData toState, boolean bCheckOnly)
	{
		if(bCheckOnly == false)
		{
			GetManager().TimingEventLog(getEventFullString(_event), toState.state_guid);
		}
	
		if (instance != null)
			return instance.dispatch(_event, toState, bCheckOnly);
			
		return false;
	}

};