public class StateInitialData 
{
	public StateInitialData(int state_, int parent_state_, int region_count_, boolean isSubmachineState_, String name, String guid, String instanceName_)
	{
		state_enum = state_;
		parent_state_enum = parent_state_;
		region_count = region_count_;
		isSubmachineState = isSubmachineState_;
		state_name = name;
        state_guid = guid;
		
		instanceName = instanceName_;
	}
	
	public int state_enum;
	public int parent_state_enum;
	public int region_count;				//submachineState's region count == submachine's region count
	public boolean isSubmachineState;
	public String state_name;
    public String state_guid;
	
	//For Timing Logging
	public String instanceName;
};