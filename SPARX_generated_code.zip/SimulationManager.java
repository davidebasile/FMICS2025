import java.util.*;


public class SimulationManager extends ContextManager
{
	C_CSL C_CSL;
	SAI I_SAI;
	SAI C_SAI;
	RBC_USER C_RBC_USER;
	I_CSL I_CSL;
	RBC_USER I_RBC_USER;
	TIMER TIMER;
	public SimulationManager()
    {
		C_CSL = new C_CSL(this, "C_CSL");
		C_CSL.max_receive_timer = 1;
		C_CSL.max_send_timer = 1;
		lstContext.add(C_CSL.m_StateMachineImpl);
		I_SAI = new SAI(this, "I_SAI");
		lstContext.add(I_SAI.m_StateMachineImpl);
		C_SAI = new SAI(this, "C_SAI");
		lstContext.add(C_SAI.m_StateMachineImpl);
		C_RBC_USER = new RBC_USER(this, "C_RBC_USER");
		lstContext.add(C_RBC_USER.m_StateMachineImpl);
		I_CSL = new I_CSL(this, "I_CSL");
		I_CSL.max_receive_timer = 1;
		I_CSL.max_connect_timer = 3;
		I_CSL.max_send_timer = 1;
		lstContext.add(I_CSL.m_StateMachineImpl);
		I_RBC_USER = new RBC_USER(this, "I_RBC_USER");
		lstContext.add(I_RBC_USER.m_StateMachineImpl);
		TIMER = new TIMER(this, "TIMER");
		lstContext.add(TIMER.m_StateMachineImpl);
		//setup instance associations
		I_CSL.RBC_USER = I_RBC_USER;
		C_CSL.SAI = C_SAI;
		I_CSL.TIMER = TIMER;
		C_CSL.TIMER = TIMER;
		I_CSL.SAI = I_SAI;
		C_CSL.RBC_USER = C_RBC_USER;
		m_pCommand = new StringBuilder();
	
		for (int i = 0; i < GlobalFuncs.MAX_STATES; i++)
		{
			activeStates[i] = null;
		}
		activeStateCount=0;	
    }
	public void finalize() throws Throwable
    {
	    if(m_pCommand != null)
	    {
		    m_pCommand = null;
	    }
    }
	
	public void ClearInstance(String instanceStr)
	{
		if(instanceStr != null && instanceStr.compareTo("C_CSL") == 0)
			C_CSL = null;
		if(instanceStr != null && instanceStr.compareTo("I_SAI") == 0)
			I_SAI = null;
		if(instanceStr != null && instanceStr.compareTo("C_SAI") == 0)
			C_SAI = null;
		if(instanceStr != null && instanceStr.compareTo("C_RBC_USER") == 0)
			C_RBC_USER = null;
		if(instanceStr != null && instanceStr.compareTo("I_CSL") == 0)
			I_CSL = null;
		if(instanceStr != null && instanceStr.compareTo("I_RBC_USER") == 0)
			I_RBC_USER = null;
		if(instanceStr != null && instanceStr.compareTo("TIMER") == 0)
			TIMER = null;
	}
	
	public StringBuilder m_pCommand;
	public Queue<String> m_commands = new LinkedList<String>();
	
    public void Run()
    {
		simulationStartTime = System.currentTimeMillis();
	
		boolean bContinue=true;
	    RunAllStateMachines();
	    while(bContinue)
	    {
			SetActiveStates();
			
		    ///////////////////
		    OnStepComplete();
		    ///////////////////
			
		    String sIn = Dequeue();
			
			bContinue = EvaluateCommandString(sIn);
	    }
    }
	
	public String GetStatePath(StateData pState)
	{
		String strPath = "";
		Stack<String> names = new Stack<String>();	
		
		StateData parent = pState;
		while (parent != null)
		{
			if(!parent.state_guid.isEmpty())
			{
				names.push(parent.state_guid);
			}
			parent = parent.parent_state;
		}
		
		while (!names.isEmpty())
		{
			String name = names.pop();
			if (!name.isEmpty())
			{
				if(!strPath.isEmpty())
				{
					strPath += ",";
				}			
				strPath += name;			
			}
		}
		
		return strPath;	
	}
	
	public void SetActiveStates()
	{
		ClearActiveStates();
		
		for (int index = 0; index < lstContext.size(); index++)
		{
			StateMachineImpl pContext = lstContext.get(index);
			if (pContext != null)
			{
				for (int i = 0; i < pContext.GetStateData().size(); i++)
				{
					StateData pState = pContext.GetStateData().get(i);
					if (pState != null && pState.active_count == 1)
					{
						String pStatePath = pContext.GetInstanceName() + "," + GetStatePath(pState);
						activeStates[activeStateCount++] = pStatePath;
					}
				}			
			}
		}
	}
	
	public void ClearActiveStates()
	{
		for(int i = 0; i < activeStateCount; i++)
		{
			String pString =  activeStates[i];
			if(pString != null)
			{
				pString = null;
				activeStates[i] = null;
			}
		}
		activeStateCount = 0;	
	}
	
	public String[]	activeStates = new String[GlobalFuncs.MAX_STATES];
	
	public int activeStateCount;
	
    public String Dequeue( )
    {
		String strTrigger = "";
		if (m_commands.size() != 0)
		{
			strTrigger = m_commands.poll();
		}
		return strTrigger;
    }
	
	public void OnStepComplete()
    {
	    // Synchronization point for EA
	    if (m_pCommand != null)
	    {
		    String strTrigger = m_pCommand.toString();
			if (!strTrigger.isEmpty())
			{
				m_commands.add(strTrigger);
				m_pCommand.setLength(0);
			}
	    }
    }
	
    public static void main(String[] args)
    {
		EventProxy.initializeStrings();
        SimulationManager manager = new SimulationManager();
        manager.initialize();
        manager.Run();
		System.exit(0);
    } 
};
