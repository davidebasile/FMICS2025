import java.util.*;


/**
 * The Communication Supervision Layer class.
 * @author Davide Basile (ISTI CNR Italy)
 * @version 1.0
 * @created 17-May-2023 6:32:45 PM
 */
public class I_CSL implements StateMachineContext {

	/**
	 * Accumulating time since last SAI_CONNECT_REQUEST. 
	 */
	private int connect_timer;
	/**
	 * This attribute represents the maximum amount of time that CSL waits after the
	 * last connection request issued to the SAI, before issuing a new one.
	 */
	public int max_connect_timer;
	/**
	 * The maximum amount of time the CSL waits  for a message from SAI before closing
	 * the connection.
	 */
	public int max_receive_timer;
	/**
	 * The maximum amount of time in which the CSL sends a message to underlying layer
	 * SAI. When this threshold is reached, the CSL will issue a LifeSign message.
	 */
	public int max_send_timer;
	/**
	 * Accumulating time since last message received from SAI.
	 */
	private int receive_timer;
	/**
	 * Accumulating time since last message.
	 */
	private int send_timer;
	public SAI SAI;
	public TIMER TIMER;
	public RBC_USER RBC_USER;

	/* Begin - EA generated code for StateMachine */


	enum StateMachineEnum 
	{
		NOSTATEMACHINE,
		I_CSL_ENUM_I_CSL
	};

	enum StateEnum 
	{
		NOSTATE,
		I_CSL_VIRTUAL_SUBMACHINESTATE,
		I_CSL_ENUM_I_CSL_COMMS,
		I_CSL_ENUM_I_CSL_NOCOMMS
	};

	enum TransitionEnum 
	{
		NOTRANSITION,
		I_CSL_ENUM_COMMS__TO__COMMS_3013,
		I_CSL_ENUM_COMMS__TO__NOCOMMS_2966,
		I_CSL_ENUM_COMMS__TO__COMMS_244,
		I_CSL_ENUM_COMMS__TO__COMMS_242,
		I_CSL_ENUM_COMMS__TO__NOCOMMS_2965,
		I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_3009,
		I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_235,
		I_CSL_ENUM_COMMS__TO__COMMS_241,
		I_CSL_ENUM_COMMS__TO__COMMS_239,
		I_CSL_ENUM_COMMS__TO__COMMS_238,
		I_CSL_ENUM_INITIAL_168__TO__NOCOMMS_229,
		I_CSL_ENUM_NOCOMMS__TO__COMMS_3011,
		I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_3010
	};

	enum EntryEnum
	{
		NOENTRY,
		I_CSL_ENUM_I_CSL_INITIAL_168
	};

	public StateMachineImpl m_StateMachineImpl;	
	
	public I_CSL()
	{
		m_StateMachineImpl = null;
	}
	
	protected void finalize( ) throws Throwable
	{
	}
	
	public I_CSL(ContextManager pManager, String sInstanceName)
	{
		//Initialize Region Variables
		m_i_csl = StateEnum.NOSTATE;	
		m_sInstanceName = sInstanceName;
		m_sType = "I_CSL";
		m_StateMachineImpl = new StateMachineImpl(this, pManager);
	}
	
    public String m_sInstanceName;
    public String m_sType;
	
	public String GetInstanceName()
	{
		return m_sInstanceName;
	}
	
	public String GetTypeName()
	{
		return m_sType;
	}
	
	public boolean defer(Event event, StateData toState)
	{
		if (m_StateMachineImpl == null)
			return false;
		
		boolean bDefer = false;
    
		
		if(!bDefer)
		{
			if(toState.parent_state != null)
			{
				bDefer = defer(event, toState.parent_state);
			}
		}
		return bDefer;
	}

	public void TransitionProc(TransitionEnum transition, Signal signal, StateData submachineState)
	{
		if (m_StateMachineImpl == null)
			return;
		
	
		switch (transition) 
		{
			case I_CSL_ENUM_COMMS__TO__COMMS_3013:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_COMMS__TO__COMMS_3013", "{0240118C-1BCB-4553-9555-8C8F9D8FEB0E}",m_sInstanceName);
				COMMS__TO__COMMS_3013(signal, submachineState); 
				break;
			case I_CSL_ENUM_COMMS__TO__NOCOMMS_2966:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_COMMS__TO__NOCOMMS_2966", "{0EB15EC5-6F56-48f5-9D27-E15597FE2507}",m_sInstanceName);
				COMMS__TO__NOCOMMS_2966(signal, submachineState); 
				break;
			case I_CSL_ENUM_COMMS__TO__COMMS_244:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_COMMS__TO__COMMS_244", "{131CCA21-85EE-43fd-BE52-19A8082D567A}",m_sInstanceName);
				COMMS__TO__COMMS_244(signal, submachineState); 
				break;
			case I_CSL_ENUM_COMMS__TO__COMMS_242:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_COMMS__TO__COMMS_242", "{3B732ADA-B9AC-4be5-AEC8-D7FDF54F20E2}",m_sInstanceName);
				COMMS__TO__COMMS_242(signal, submachineState); 
				break;
			case I_CSL_ENUM_COMMS__TO__NOCOMMS_2965:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_COMMS__TO__NOCOMMS_2965", "{42B92EB5-06D8-46b0-AA46-D9BE5A68DB53}",m_sInstanceName);
				COMMS__TO__NOCOMMS_2965(signal, submachineState); 
				break;
			case I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_3009:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_NOCOMMS__TO__NOCOMMS_3009", "{4AFAC37A-9122-4928-A325-06095DD215D3}",m_sInstanceName);
				NOCOMMS__TO__NOCOMMS_3009(signal, submachineState); 
				break;
			case I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_235:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_NOCOMMS__TO__NOCOMMS_235", "{56883C99-1D38-46e9-987C-0E49B3A9952D}",m_sInstanceName);
				NOCOMMS__TO__NOCOMMS_235(signal, submachineState); 
				break;
			case I_CSL_ENUM_COMMS__TO__COMMS_241:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_COMMS__TO__COMMS_241", "{57DD5336-2D4B-463f-8EA7-52F14ABFF6CB}",m_sInstanceName);
				COMMS__TO__COMMS_241(signal, submachineState); 
				break;
			case I_CSL_ENUM_COMMS__TO__COMMS_239:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_COMMS__TO__COMMS_239", "{9D0E786B-8781-4d25-BE70-795490D36C30}",m_sInstanceName);
				COMMS__TO__COMMS_239(signal, submachineState); 
				break;
			case I_CSL_ENUM_COMMS__TO__COMMS_238:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_COMMS__TO__COMMS_238", "{AA930C3C-DE2D-44bb-94F8-45A059BC4E22}",m_sInstanceName);
				COMMS__TO__COMMS_238(signal, submachineState); 
				break;
			case I_CSL_ENUM_INITIAL_168__TO__NOCOMMS_229:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_Initial_168__TO__NOCOMMS_229", "{D04CB818-0F32-48cb-A163-568797666A6C}",m_sInstanceName);
				Initial_168__TO__NOCOMMS_229(signal, submachineState); 
				break;
			case I_CSL_ENUM_NOCOMMS__TO__COMMS_3011:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_NOCOMMS__TO__COMMS_3011", "{D478F2BC-11BD-40ec-83DF-B7C1B9034FF9}",m_sInstanceName);
				NOCOMMS__TO__COMMS_3011(signal, submachineState); 
				break;
			case I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_3010:
				m_StateMachineImpl.currentTransition.SetTransition(transition.ordinal(), submachineState, "I_CSL_NOCOMMS__TO__NOCOMMS_3010", "{DD79915B-FAF8-4fd7-8D7E-5E00EF03774A}",m_sInstanceName);
				NOCOMMS__TO__NOCOMMS_3010(signal, submachineState); 
				break;
		}
	
		m_StateMachineImpl.currentTransition.SetTransition(TransitionEnum.NOTRANSITION.ordinal(), null, "", "","");	
	}
	
	private void COMMS__TO__COMMS_3013_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_3013");
	
		this.receive_timer=0;
		 m_StateMachineImpl.m_pManager.SendEvent("RBC_USER_DATA_INDICATION.sig_user("+signal.parameterValues.get("udata")+")",RBC_USER.m_StateMachineImpl);

	}

	private void COMMS__TO__COMMS_3013(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_3013_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__NOCOMMS_2966_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__NOCOMMS_2966");
	
	
		this.receive_timer=0; this.send_timer=0;
		m_StateMachineImpl.m_pManager.SendEvent("OK_TICK",TIMER.m_StateMachineImpl);
		m_StateMachineImpl.m_pManager.SendEvent("RBC_USER_DISCONNECT_INDICATION",RBC_USER.m_StateMachineImpl);
		m_StateMachineImpl.m_pManager.SendEvent("SAI_DISCONNECT_REQUEST",SAI.m_StateMachineImpl);
	

	}

	private void COMMS__TO__NOCOMMS_2966(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__NOCOMMS_2966_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_244_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_244");
	
		this.send_timer=0;
		
		m_StateMachineImpl.m_pManager.SendEvent("SAI_DATA_REQUEST.sig_sai(Data,"+signal.parameterValues.get("udata")+")",SAI.m_StateMachineImpl);

	}

	private void COMMS__TO__COMMS_244(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_244_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_242_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_242");
	
		this.send_timer = this.send_timer+ 1;
		this.receive_timer = this.receive_timer+1;
	
		m_StateMachineImpl.m_pManager.SendEvent("OK_TICK",TIMER.m_StateMachineImpl);

	}

	private void COMMS__TO__COMMS_242(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_242_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__NOCOMMS_2965_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__NOCOMMS_2965");
	
		m_StateMachineImpl.m_pManager.SendEvent("RBC_USER_DISCONNECT_INDICATION",RBC_USER.m_StateMachineImpl);
		this.receive_timer=0;
		this.send_timer=0;

	}

	private void COMMS__TO__NOCOMMS_2965(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__NOCOMMS_2965_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void NOCOMMS__TO__NOCOMMS_3009_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: NOCOMMS__TO__NOCOMMS_3009");
	
		this.connect_timer = this.connect_timer+1;
	
		m_StateMachineImpl.m_pManager.SendEvent("OK_TICK",TIMER.m_StateMachineImpl);

	}

	private void NOCOMMS__TO__NOCOMMS_3009(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.EXIT, null);
		NOCOMMS__TO__NOCOMMS_3009_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void NOCOMMS__TO__NOCOMMS_235_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: NOCOMMS__TO__NOCOMMS_235");
	
	}

	private void NOCOMMS__TO__NOCOMMS_235(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.EXIT, null);
		NOCOMMS__TO__NOCOMMS_235_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_241_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_241");
	
		this.send_timer = 0;
		this.receive_timer = this.receive_timer+1;
		
	
		m_StateMachineImpl.m_pManager.SendEvent("OK_TICK",TIMER.m_StateMachineImpl);
		m_StateMachineImpl.m_pManager.SendEvent("SAI_DATA_REQUEST.sig_sai(LifeSign,nodata)",SAI.m_StateMachineImpl);

	}

	private void COMMS__TO__COMMS_241(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_241_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_239_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_239");
	
		this.receive_timer = 0;

	}

	private void COMMS__TO__COMMS_239(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_239_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void COMMS__TO__COMMS_238_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: COMMS__TO__COMMS_238");
	
	}

	private void COMMS__TO__COMMS_238(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.EXIT, null);
		COMMS__TO__COMMS_238_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void Initial_168__TO__NOCOMMS_229_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: Initial_168__TO__NOCOMMS_229");
	
		this.connect_timer=this.max_connect_timer;
		this.receive_timer=0;
		this.send_timer=0;

	}

	private void Initial_168__TO__NOCOMMS_229(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(submachineState != null)
			submachineState.IncrementActiveCount();
		Initial_168__TO__NOCOMMS_229_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void NOCOMMS__TO__COMMS_3011_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: NOCOMMS__TO__COMMS_3011");
	
		this.connect_timer=this.max_connect_timer;
	
		m_StateMachineImpl.m_pManager.SendEvent("RBC_USER_CONNECT_INDICATION",RBC_USER.m_StateMachineImpl);

	}

	private void NOCOMMS__TO__COMMS_3011(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.EXIT, null);
		NOCOMMS__TO__COMMS_3011_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_COMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	private void NOCOMMS__TO__NOCOMMS_3010_effect(Signal signal)
	{
		GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Transition Effect: NOCOMMS__TO__NOCOMMS_3010");
	
		this.connect_timer = 0;
	
		m_StateMachineImpl.m_pManager.SendEvent("OK_TICK",TIMER.m_StateMachineImpl);
	
		m_StateMachineImpl.m_pManager.SendEvent("SAI_CONNECT_REQUEST",SAI.m_StateMachineImpl);

	}

	private void NOCOMMS__TO__NOCOMMS_3010(Signal signal, StateData submachineState) 
	{
		if (m_StateMachineImpl == null)
			return;
	
		if(!m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS.ordinal()).IsActiveState())
		{
			return;
		}
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.EXIT, null);
		NOCOMMS__TO__NOCOMMS_3010_effect(signal);
		m_StateMachineImpl.currentTransition.SetActive(m_StateMachineImpl);
		StateProc(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS, submachineState, StateBehaviorEnum.ENTRY, signal, EntryTypeEnum.DefaultEntry);
	}
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal)
	{
		return StateProc(state, submachineState, behavior, signal, EntryTypeEnum.DefaultEntry, null, 0);
	}
	
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType)
	{
		return StateProc(state, submachineState, behavior, signal, enumEntryType, null, 0);
	}
	
	public boolean StateProc(int state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, int[] entryArray, int nArrayCount)
    {
		ArrayList<EntryEnum> entryEnumList = new ArrayList<>();
		if (entryArray != null)
		{
			for(int nEntryIndex : entryArray)
			{
				entryEnumList.add(EntryEnum.values()[nEntryIndex]);
			}
		}
        return StateProc(StateEnum.values()[state], submachineState, behavior, signal, enumEntryType, entryEnumList.toArray(new EntryEnum[entryEnumList.size()]), nArrayCount);
    }
	
	public boolean StateProc(StateEnum state, StateData submachineState, StateBehaviorEnum behavior, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount)
	{
		switch (state) 
		{
			case I_CSL_ENUM_I_CSL_COMMS:
				I_CSL_COMMS(behavior, submachineState, signal, enumEntryType, entryArray, nArrayCount);
				break;

			case I_CSL_ENUM_I_CSL_NOCOMMS:
				I_CSL_NOCOMMS(behavior, submachineState, signal, enumEntryType, entryArray, nArrayCount);
				break;
		}
		return false;
	}
	
	public boolean I_CSL_COMMS(StateBehaviorEnum behavior, StateData submachineState, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount) 
	{
		if (m_StateMachineImpl == null)
			return false;
	
		StateData state = m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal());
		switch (behavior) 
		{
			case ENTRY:
				if(state.active_count > 0)
					return false;
				m_i_csl = StateEnum.I_CSL_ENUM_I_CSL_COMMS;
				state.IncrementActiveCount();
				I_CSL_COMMS_behavior(StateBehaviorEnum.ENTRY);
						
				I_CSL_COMMS_behavior(StateBehaviorEnum.DO);
			
				if((enumEntryType == EntryTypeEnum.EntryPointEntry || enumEntryType == EntryTypeEnum.DefaultEntry) && state.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, state);
				break;
			case EXIT:
				if(state.active_count == 0)
					return false;
				m_i_csl = StateEnum.NOSTATE;
				state.DecrementActiveCount();
				I_CSL_COMMS_behavior(StateBehaviorEnum.EXIT);
				m_StateMachineImpl.removeInternalEvent(state);
				break;
		}
	
		return true;
	}

	public boolean I_CSL_COMMS_behavior(StateBehaviorEnum behavior)
	{
		switch (behavior) 
		{
			case ENTRY:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Entry Behavior: I_CSL_COMMS");
			}
			break;
			case DO:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Do Behavior: I_CSL_COMMS");
			}
			break;
			case EXIT:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Exit Behavior: I_CSL_COMMS");
			}
			break;
		}
	
		return true;
	}
	public boolean I_CSL_NOCOMMS(StateBehaviorEnum behavior, StateData submachineState, Signal signal, EntryTypeEnum enumEntryType, EntryEnum[] entryArray, int nArrayCount) 
	{
		if (m_StateMachineImpl == null)
			return false;
	
		StateData state = m_StateMachineImpl.GetStateObject(submachineState, StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS.ordinal());
		switch (behavior) 
		{
			case ENTRY:
				if(state.active_count > 0)
					return false;
				m_i_csl = StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS;
				state.IncrementActiveCount();
				I_CSL_NOCOMMS_behavior(StateBehaviorEnum.ENTRY);
						
				I_CSL_NOCOMMS_behavior(StateBehaviorEnum.DO);
			
				if((enumEntryType == EntryTypeEnum.EntryPointEntry || enumEntryType == EntryTypeEnum.DefaultEntry) && state.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, state);
				break;
			case EXIT:
				if(state.active_count == 0)
					return false;
				m_i_csl = StateEnum.NOSTATE;
				state.DecrementActiveCount();
				I_CSL_NOCOMMS_behavior(StateBehaviorEnum.EXIT);
				m_StateMachineImpl.removeInternalEvent(state);
				break;
		}
	
		return true;
	}

	public boolean I_CSL_NOCOMMS_behavior(StateBehaviorEnum behavior)
	{
		switch (behavior) 
		{
			case ENTRY:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Entry Behavior: I_CSL_NOCOMMS");
			}
			break;
			case DO:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Do Behavior: I_CSL_NOCOMMS");
			}
			break;
			case EXIT:
			{
				GlobalFuncs.trace("[" + m_sInstanceName + ":" + m_sType + "] Exit Behavior: I_CSL_NOCOMMS");
			}
			break;
		}
	
		return true;
	}
	public boolean dispatch(Event event, StateData toState, boolean bCheckOnly)
	{
		if (m_StateMachineImpl == null)
			return false;
		
		boolean bDispatched = false;
		if(toState == null || !toState.IsActiveState() && !bCheckOnly)
			return bDispatched;
		
		switch (StateEnum.values()[toState.state_enum]) 
		{
			case I_CSL_VIRTUAL_SUBMACHINESTATE:
				if(event.eventEnum == EventProxy.EventEnum.COMPLETION)
				{
					if(!bCheckOnly)
					{
						m_StateMachineImpl.ReleaseSubmachineState(toState);
						for (int index = m_StateMachineImpl.lstStateData.size() - 1; index >= 0; index--)
						{
							StateData state = m_StateMachineImpl.lstStateData.get(index);
							if (state == toState)
							{
								m_StateMachineImpl.lstStateData.remove(state);
								break;
							}						
						}
						//delete toState;
						toState = null;
					}				
					bDispatched = true;
				}
				break;
			case I_CSL_ENUM_I_CSL_COMMS:
				switch (event.eventEnum) 
				{
					case ENUM_SAI_DATA_INDICATION:
						if(!event.signal.parameterValues.get("mtype").equals("LifeSign")) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.I_CSL_ENUM_COMMS__TO__COMMS_3013, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						if(event.signal.parameterValues.get("mtype").equals("LifeSign")) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.I_CSL_ENUM_COMMS__TO__COMMS_239, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						break;
					case ENUM_TICK:
						if(this.receive_timer==this.max_receive_timer) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.I_CSL_ENUM_COMMS__TO__NOCOMMS_2966, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						if(this.receive_timer < this.max_receive_timer || this.send_timer<this.max_send_timer) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.I_CSL_ENUM_COMMS__TO__COMMS_242, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						if(this.receive_timer<this.max_receive_timer && this.send_timer==this.max_send_timer) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.I_CSL_ENUM_COMMS__TO__COMMS_241, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						break;
					case ENUM_RBC_USER_DATA_REQUEST:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.I_CSL_ENUM_COMMS__TO__COMMS_244, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_DISCONNECT_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.I_CSL_ENUM_COMMS__TO__NOCOMMS_2965, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_ERROR_REPORT:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.I_CSL_ENUM_COMMS__TO__COMMS_238, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
				}
				break;
			case I_CSL_ENUM_I_CSL_NOCOMMS:
				switch (event.eventEnum) 
				{
					case ENUM_TICK:
						if(this.connect_timer<this.max_connect_timer) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_3009, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						if(this.connect_timer==this.max_connect_timer) 
						{
							if(!bCheckOnly)
								TransitionProc(TransitionEnum.I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_3010, event.signal, toState.submachine_state);
							bDispatched = true;
							break;
						}
						break;
					case ENUM_RBC_USER_DATA_REQUEST:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_235, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_DISCONNECT_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_235, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_ERROR_REPORT:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_235, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_DATA_INDICATION:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.I_CSL_ENUM_NOCOMMS__TO__NOCOMMS_235, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
					case ENUM_SAI_CONNECT_CONFIRM:
						if(!bCheckOnly)
							TransitionProc(TransitionEnum.I_CSL_ENUM_NOCOMMS__TO__COMMS_3011, event.signal, toState.submachine_state);
						bDispatched = true;
						break;
				}
				break;
		}
		
		if (!bDispatched && toState != null && toState.parent_state != null && event.eventEnum != EventProxy.EventEnum.COMPLETION)
		{
			bDispatched = dispatch(event, toState.parent_state, true);
			if (bDispatched && !bCheckOnly)
			{
				/*1. Exit the current state; 2. Decrement the active count of the parent state; 3. dispatch the event to parent state*/
				StateProc(StateEnum.values()[toState.state_enum], toState.submachine_state, StateBehaviorEnum.EXIT, null);
				toState.parent_state.DecrementActiveCount();
				dispatch(event, toState.parent_state, false);
				event = null;
			}
		}
		
		return bDispatched;
	}
	
	StateEnum m_i_csl;
	
	@Override
    public void runStateMachine(String statemachine)
    {
		if(statemachine.equals("I_CSL_I_CSL"))
		{
			runStateMachine(StateMachineEnum.I_CSL_ENUM_I_CSL);
			return;
		}
    }
	
	private void runStateMachine(StateMachineEnum statemachine, StateData submachineState, Signal signal)
	{
		runStateMachine(statemachine, submachineState, signal, null, 0);
	}
	
	private void runStateMachine(StateMachineEnum statemachine, StateData submachineState, Signal signal, EntryEnum[] entryArray, int nEntryCount)
	{
		if (m_StateMachineImpl == null)
			return;
		
		if(submachineState == null)
		{
			StateInitialData initialData = new StateInitialData(StateEnum.I_CSL_VIRTUAL_SUBMACHINESTATE.ordinal(), StateEnum.NOSTATE.ordinal(), 1, false, "I_CSL_VIRTUAL_SUBMACHINESTATE", "", ""); 
			submachineState = new StateData(m_StateMachineImpl, initialData);
			submachineState.IncrementActiveCount();
			m_StateMachineImpl.lstStateData.add(submachineState);
		}
		switch (statemachine) 
		{
			case I_CSL_ENUM_I_CSL:
				{
					final int nArrayCount = 2;
					StateInitialData[] initialDataArray = 
						{
							new StateInitialData(StateEnum.I_CSL_ENUM_I_CSL_COMMS.ordinal(), StateEnum.NOSTATE.ordinal(), 0, false, "I_CSL_I_CSL_COMMS", "{C04AB919-649B-4d4d-9F53-21D883CA34D9}", m_sInstanceName),
							new StateInitialData(StateEnum.I_CSL_ENUM_I_CSL_NOCOMMS.ordinal(), StateEnum.NOSTATE.ordinal(), 0, false, "I_CSL_I_CSL_NOCOMMS", "{CE0B7B95-301D-48f7-B5CE-A00D4B5E9A61}", m_sInstanceName)
						};
		
					m_StateMachineImpl.CreateStateObjects(initialDataArray, nArrayCount, submachineState);
				}
				for(int i = 0; i < nEntryCount; i++)
				{
					switch(entryArray[i])
					{
					case I_CSL_ENUM_I_CSL_INITIAL_168:
						TransitionProc(TransitionEnum.I_CSL_ENUM_INITIAL_168__TO__NOCOMMS_229, signal, submachineState);
						break;
					}
				}
				if(submachineState.IsActiveState())
					m_StateMachineImpl.deferInternalEvent(EventProxy.EventEnum.COMPLETION, null, submachineState);
				break;
		}
	
	}
	
	public void runStateMachine(StateMachineEnum statemachine)
	{
		if (m_StateMachineImpl == null)
			return;
		
		List<StateData> activeStateArray = new ArrayList<StateData>();
		if(m_StateMachineImpl.GetCurrentStates(activeStateArray) > 0)
			return;
		switch (statemachine) 
		{
			case I_CSL_ENUM_I_CSL:
				{
					final int nArrayCount = 1;
					EntryEnum[] entryArray = {EntryEnum.I_CSL_ENUM_I_CSL_INITIAL_168};
					runStateMachine(statemachine, null, null, entryArray, nArrayCount);	//submachineState is NULL if run standalone statemachine 
				}
				break;
		}
	}
	
	public void runStateMachines()
	{
		runStateMachine(StateMachineEnum.I_CSL_ENUM_I_CSL);	
	}


	/* End - EA generated code for StateMachine */
}//end I_CSL