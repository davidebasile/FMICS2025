import java.util.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


class InternalEventData 
{
	public InternalEventData(Event event_, StateData state_)
	{
		event = event_;
		state = state_;	
	}
	
	protected void finalize( ) throws Throwable
	{
	}
	
	public Event event = null;
	public StateData state = null;
};

class EventData
{
	public String evtStr;
	public String signalStr;
	public List<String> arguments;
};

public class ContextManager
{
	public ContextManager()
	{
	}
	protected void finalize( ) throws Throwable
	{
	}
	
	public List<StateMachineImpl> lstContext = new ArrayList<StateMachineImpl>();

	
	public long simulationStartTime = 0;
	public List<String> lstTimingEventLog = new ArrayList<String>();	
	public List<String> lstTimingLog = new ArrayList<String>();	
	
	public void TimingEventLog(String eventName, String stateGuid)
	{
		long timeNow = System.currentTimeMillis();
		lstTimingEventLog.add((timeNow - simulationStartTime) + "," + eventName + "," + stateGuid);
	}
	
	public void TimingLog(String instanceName, String stateGuid, String action)
	{
		long timeNow = System.currentTimeMillis();
		lstTimingLog.add((timeNow - simulationStartTime) + "," + instanceName + "," + stateGuid + "," + action);
	}
	
	public void DumpTimingLog()
	{
		GlobalFuncs.trace("TimingEventLog Begin\n");
		for (String temp : lstTimingEventLog) 
		{
			GlobalFuncs.trace("\t" + temp + "\n");
		}
		GlobalFuncs.trace("TimingEventLog End\n");
		
		GlobalFuncs.trace("TimingLog Begin\n");
		for (String temp : lstTimingLog) 
		{
			GlobalFuncs.trace("\t" + temp + "\n");
		}
		GlobalFuncs.trace("TimingLog End\n");
	}
	
	public void initialize()
	{
		for (int index = 0; index < lstContext.size(); index++)
		{
			StateMachineImpl context = lstContext.get(index);
			context.initializeStateMachine();
		}
	}
	
	public void RunAllStateMachines()
	{
		for (int index = 0; index < lstContext.size(); index++)
		{
			StateMachineImpl context = lstContext.get(index);
			context.runStateMachines();
		}
	}
	
	public void BroadCastEvent(String eventStr)
	{
		EventData eventData = new EventData();
		GlobalFuncs.ParseEventString(eventStr, eventData);
		
		Signal signal = EventProxy.GetSignalInstance(eventData.signalStr, eventData.arguments);
		if (StringTable.stringTable.mapStringToEventEnum.containsKey(eventData.evtStr))
			BroadCastEvent(StringTable.stringTable.mapStringToEventEnum.get(eventData.evtStr), signal);
	}
	
	public void BroadCastEvent(EventProxy.EventEnum eventEnum_, Signal signal)
	{
		for (int index = 0; index < lstContext.size(); index++)
		{
			StateMachineImpl context = lstContext.get(index);
			context.EventOccurance(eventEnum_, signal);
		}
	}
	
	public void SendEvent(String eventStr, String contextStr)
	{
		StateMachineImpl context = null;
		
		for (int index = 0; index < lstContext.size(); index++)
		{
			StateMachineImpl searchContext = lstContext.get(index);
			if (searchContext != null && contextStr != null && contextStr.compareTo(searchContext.GetInstanceName()) == 0)
			{
				context = searchContext;
				break;
			}
		}
		if(context != null)
		{
			SendEvent(eventStr, context);
		}
	}
	
	public void SendEvent(String eventStr, StateMachineImpl target)
	{
		if (target != null)
		{
			EventData eventData = new EventData();
			GlobalFuncs.ParseEventString(eventStr, eventData);
			Signal signal = EventProxy.GetSignalInstance(eventData.signalStr, eventData.arguments);
			if (StringTable.stringTable.mapStringToEventEnum.containsKey(eventData.evtStr))
				SendEvent(StringTable.stringTable.mapStringToEventEnum.get(eventData.evtStr), signal, target);
		}
	}

	public void SendEvent(EventProxy.EventEnum eventEnum_, Signal signal, StateMachineImpl target)
	{
		target.EventOccurance(eventEnum_, signal);
	}

	public boolean EvaluateCommandString(String commandStr)	//return true if continue waiting for next command; return false if break
	{
		if (commandStr == null)
			return false;
		
		if(!commandStr.isEmpty())
		{
			GlobalFuncs.trace("Command: " + commandStr);
		}
		
		String command = "";
		String instance = "";
		String statemachine = "";
		String eventString = "";
		
		if(commandStr.indexOf("run ") != -1) 
		{
			command = "run";
			String argument = commandStr.substring(4);
			int pos = argument.indexOf(".");
			if(pos != -1) 
			{
				instance = argument.substring(0, pos);
				statemachine = argument.substring(pos + 1);
			} 
			else if(argument.compareTo("all") == 0) 
			{
				instance = "all";
				statemachine = "all";
			} 
			else if(!argument.isEmpty())
			{
				instance = argument;
				statemachine = "all";
			}
		} 
		else if(commandStr.compareTo("run") == 0) 
		{
			command = "run";
			instance = "all";
			statemachine = "all";		
		} 
		else if(commandStr.indexOf("broadcast ") != -1) 
		{
			command = "broadcast";
			instance = "all";
			eventString = commandStr.substring(10);
			BroadCastEvent(eventString);
		} 
		else if(commandStr.indexOf("send ") != -1) 
		{
			command = "send";
			String argument = commandStr.substring(5);
			int pos = argument.indexOf(" to ");
			if(pos != -1) 
			{
				eventString = argument.substring(0, pos);
				instance = argument.substring(pos + 4);
			}
			else
			{
				eventString = argument;
				instance = "all";
			}
		} 
		else if(commandStr.indexOf("dump ") != -1) 
		{
			command = "dump";
			instance = commandStr.substring(5);
		} 
		else if(commandStr.compareTo("dump") == 0) 
		{
			command = "dump";
			instance = "all";
		} 
		else if (commandStr.compareTo("dumpTimingLog") == 0) 
		{
			DumpTimingLog();
			return true;
		} 
		else if (commandStr.compareTo("exit") == 0) 
		{
			command = "exit";
			return false;
		} 
		else if (commandStr.compareTo("stepall") == 0) 
		{
			command = "stepall";
			instance = "all";
		} 
		else 
		{
			command = "step";
			instance = "all";
		}
		
		for (int index = 0; index < lstContext.size(); index++)
		{
			StateMachineImpl context = lstContext.get(index);
			if (context != null)
			{
				if (instance=="all")
					RunCommand(command, context, statemachine, eventString);
				else if (instance.equals(context.GetInstanceName()))
				{
					RunCommand(command, context, statemachine, eventString);
					break;
				}
				/*if (command.compareTo("broadcast") != 0)
				{
					RunCommand(command, context, statemachine, eventString);
					if (instance.compareTo(context.GetInstanceName()) == 0)
						break;
				}*/
				else
				{
					context.recall();
				}
			}
		}
		
		//if any of the context reach a terminiate
		int count = lstContext.size();
		for (int i = (count - 1); i >= 0; i--)
		{
			StateMachineImpl context = lstContext.get(i);
			if (context != null && context.IsTerminated() == true)
			{
				lstContext.remove(i);
				ClearInstance(context.GetInstanceName());
				// delete context;
				context = null;
			}
		}
		
		if(IsSimulationEnded()) {
			return false;
		}
		return true;
	}
	
	public boolean IsSimulationEnded()
	{
		boolean bIsSimulationEnded = true;
		for (int contextIndex = 0; contextIndex < lstContext.size(); contextIndex++)
		{
			StateMachineImpl context = lstContext.get(contextIndex);
			if(context != null)
			{
				for (int stateIndex = 0; stateIndex < context.lstStateData.size(); stateIndex++)
				{				
					StateData state = context.lstStateData.get(stateIndex);
					if(state != null && state.active_count > 0)
					{
						bIsSimulationEnded = false;
						break;
					}
				}
				
				if(!bIsSimulationEnded){
					break;
				}
			}
		}
		
		return bIsSimulationEnded;
	}
	
	public void RunCommand(String command, StateMachineImpl context, String statemachine, String eventString)	//return true if continue waiting for next command; return false if break
	{
		if (context == null || command == null)
			return;
		if (command.compareTo("run") == 0)
		{
			if (statemachine.compareTo("all") == 0)
				context.runStateMachines(); 
			else
				context.runStateMachine(statemachine);
		}
		else if (command.compareTo("send") == 0)
		{
			SendEvent(eventString, context);
		}
		else if (command.compareTo("dump") == 0)
		{
			context.DumpActiveCnt();
		}
		else if (command.compareTo("stepall") == 0)
        {
            while(true)
            {
                if(!context.recallOneInternalEvent())
                    break;
            }
			
			// This is a wait point, get an event from the pool and dispatch it
			context.recall();
        }
		else if (command.compareTo("step") == 0)
		{
			if (!context.recallOneInternalEvent())
			{
				//This is a wait point, get an event from the pool and dispatch it
				context.recall();
			}
		}
	}
	
	public void ClearInstance(String instanceStr)
	{	
	}
	
	public void Run()
	{
	}
	
	public void OnStateChange(StateData stateData)		//SimulationManager will overwrite
	{
	}
	
	public void OnTransition( TransitionData transitionData)	//SimulationManager will overwrite
	{
	}
};

class StringTable 
{
	public static StringTable stringTable = new StringTable();
		
	public Map<String, EventProxy.EventEnum> mapStringToEventEnum = new Hashtable<String, EventProxy.EventEnum>();
	public Map<EventProxy.EventEnum, String> mapEventEnumToString = new Hashtable<EventProxy.EventEnum, String>();
	public Map<EventProxy.SignalEnum, String> mapSignalEnumToString = new Hashtable<EventProxy.SignalEnum, String>();
	public Map<String, String> mapNameToGuid = new Hashtable<String, String>();
};
